export * from "./denuncias.interface";
export * from "./users.interface";

