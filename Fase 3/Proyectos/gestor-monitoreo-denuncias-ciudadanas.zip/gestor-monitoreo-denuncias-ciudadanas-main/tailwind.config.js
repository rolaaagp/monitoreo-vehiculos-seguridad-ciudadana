/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: 'class',
  content: ['./src/**/*.{html,ts}'],
  theme: {
    extend: {
      fontFamily: {
        albert: ['"Albert Sans"', 'sans-serif'],
        rubik: ['Rubik', 'sans-serif'],
        circular: ['Circular Std', 'sans-serif'],
        inter: ['Inter', 'sans-serif'],
      },
      fontSize: {
        breadcrumb: ['16px', { lineHeight: '24px', letterSpacing: '0px' }],
        pagination: ['16px', { lineHeight: '16px', letterSpacing: '0px' }],
        tablathead: ['14px', { lineHeight: '100%', letterSpacing: '0%' }],
        tablatbody: ['12px', { lineHeight: '100%', letterSpacing: '0%' }],
        titleModal: ['18px', { lineHeight: '130%', letterSpacing: '0%' }],
        subtitleModal: ['16px', { lineHeight: '34px', letterSpacing: '0px' }],
      },
      animation: {
        'fade-in': 'fadeIn 0.4s ease-out forwards',
        'fade-out': 'fadeOut 0.5s ease-in forwards'
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: 0, transform: 'translateY(-10px)' },
          '100%': { opacity: 1, transform: 'translateY(0)' }
        },
        fadeOut: {
          '0%': { opacity: 1, transform: 'translateY(0)' },
          '100%': { opacity: 0, transform: 'translateY(-10px)' }
        }
      }
    },
  },
  plugins: [require('daisyui')],
  daisyui: {
    themes: [
      {
        light: {
          primary: '#0B58A4',
          secondary: '#66BCE8',
          accent: '#00E6BF',
          neutral: '#2A2E37',
          'base-100': '#ffffff',
          'base-200': '#ffffff',
          'base-300': '#e5e5e5',
          info: '#3ABFF8',
          success: '#36D399',
          warning: '#FBBD23',
          error: '#F87272',
        },
      },
    ],
  },
};