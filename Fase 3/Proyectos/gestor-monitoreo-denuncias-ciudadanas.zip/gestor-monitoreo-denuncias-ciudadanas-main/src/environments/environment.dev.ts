export const environment = {
  production: false,
  SW: false,
  GOOGLE_CLIENT_ID: '',
  URL_FRONT: 'http://localhost:4200',
  API_DOMAINS: {
    BASE: 'https://api-monitoreo-denuncias.cloudynex.cl',
    DENUNCIAS_API: 'central-denuncias-api',
    USUARIOS_API: 'central-usuarios-api',
  },
};
