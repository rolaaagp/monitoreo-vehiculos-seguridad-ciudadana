export const environment = {
  production: false,
  SW: false,
  GOOGLE_CLIENT_ID: '280551717939-9a3bkev736acufbbd95bcbhnpgfu1v8j.apps.googleusercontent.com',
  URL_FRONT: 'http://localhost:4200',
  API_DOMAINS: {
    BASE: "https://api-monitoreo-denuncias.cloudynex.cl",
    DENUNCIAS_API: "central-denuncias-api",
    USUARIOS_API: "central-usuarios-api",
    COMMONS_API: 'central-commons-api',
  },
  GOOGLE_MAPS_KEY:'AIzaSyCIiRJaNyEXygLI0v64Re2AMoFirHd6nMc',
};
