import { Component, Input } from '@angular/core';
import { IconComponent } from '../icon/icon.component';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { SidebarComponent } from '@components/sidebar/sidebar.component';

@Component({
  selector: 'app-header',
  imports: [
    CommonModule,
    IconComponent,
    FormsModule,
  ],
  templateUrl: './header.component.html',
  styleUrl: './header.component.css',
})
export class HeaderComponent {
  @Input() clickSidebar!: SidebarComponent;

  searchQuery: string = '';
  isSearchFocused: boolean = false;

  onBlur() {
    setTimeout(() => (this.isSearchFocused = false), 1000);
  }

  clearSearch() {
    this.searchQuery = '';
  }
}
