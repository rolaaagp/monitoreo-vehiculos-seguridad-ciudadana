import { CommonModule } from '@angular/common';
import {
  Component,
  EventEmitter,
  HostListener,
  inject,
  Output,
} from '@angular/core';
import { NavigationEnd, Router, RouterModule } from '@angular/router';
import { filter } from 'rxjs';
import { IconComponent } from '@components/icon/icon.component';
import { AuthService } from '@services/auth/auth.service';
import { PROFILES } from '@shared/constants/profiles.constants';
import { HasProfileDirective } from '@directives/hasProfile.directive';

interface MenuItem {
  id: string;
  label: string;
  icon?: string;
  route?: string;
  relatedRoutes?: string[];
  submenu?: SubMenuItem[];
  profilesPermitted: number[];
}

interface SubMenuItem {
  id: string;
  label: string;
  route: string;
  profilesPermitted: number[];
}

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrl: './sidebar.component.css',
  imports: [CommonModule, RouterModule, IconComponent, HasProfileDirective],
})
export class SidebarComponent {
  @Output() collapsedChange = new EventEmitter<boolean>();
  collapsed = true;
  isMobile = false;
  currentPage: string = 'home';
  submenus: Record<string, boolean> = {};

  private router = inject(Router);

  menuItems: MenuItem[] = [
    {
      id: 'home',
      label: 'Home',
      icon: 'house-icon',
      route: '/home',
      profilesPermitted: [
        PROFILES.ADMIN,
        PROFILES.SUPERVISOR,
        PROFILES.COORDINADOR,
        PROFILES.OPERADOR_CCTV,
        PROFILES.DIRECTOR,
        PROFILES.INSPECTOR,
      ],
    },
    {
      id: 'modulo-denuncias',
      label: 'Denuncias',
      icon: 'shield',
      route: '/modulo-denuncias',
      relatedRoutes: ['/gestionar-denuncia'],
      profilesPermitted: [
        PROFILES.ADMIN,
        PROFILES.SUPERVISOR,
        PROFILES.COORDINADOR,
        PROFILES.OPERADOR_CCTV,
        PROFILES.DIRECTOR,
        PROFILES.INSPECTOR,
      ],
    },
    {
      id: 'modulo-usuarios',
      label: 'Usuarios',
      icon: 'users',
      route: '/modulo-usuarios',
      relatedRoutes: ['/gestionar-usuario'],
      profilesPermitted: [PROFILES.SUPERVISOR, PROFILES.COORDINADOR, PROFILES.ADMIN],
    },
  ];

  constructor(private readonly _authService: AuthService) {
    this.menuItems.forEach((item) => {
      if (item.submenu) {
        this.submenus[item.id] = false;
      }
    });
  }

  @HostListener('window:resize')
  onResize() {
    this.isMobile = window.innerWidth < 768;
  }

  async ngOnInit() {
    this.onResize();
    this.setCurrentPageFromUrl();

    this.router.events
      .pipe(filter((event) => event instanceof NavigationEnd))
      .subscribe(() => {
        this.setCurrentPageFromUrl();
      });
  }

  toggleSidebar() {
    this.collapsed = !this.collapsed;
    this.collapsedChange.emit(this.collapsed);
    if (this.collapsed) {
      this.closeAllSubmenus();
    }
  }

  setPage(page: string) {
    this.currentPage = page;
  }

  toggleSubmenu(submenuKey: string, event: Event) {
    event.stopPropagation();
    this.currentPage = submenuKey;
    if (this.collapsed) {
      this.toggleSidebar();
    }
    if (submenuKey in this.submenus) {
      this.submenus[submenuKey] = !this.submenus[submenuKey];
      for (const key in this.submenus) {
        if (key !== submenuKey) {
          this.submenus[key] = false;
        }
      }
    }
  }

  closeAllSubmenus() {
    for (const key in this.submenus) {
      this.submenus[key] = false;
    }
  }

  setCurrentPageFromUrl() {
    const url = this.router.url;

    const matchedItem = this.menuItems.find((item) => {
      if (item.route && url.startsWith(item.route)) {
        return true;
      }
      if (
        item.relatedRoutes &&
        item.relatedRoutes.some((route) => url.startsWith(route))
      ) {
        return true;
      }
      if (item.submenu) {
        return item.submenu.some((subitem) => url.startsWith(subitem.route));
      }
      return false;
    });

    if (matchedItem) {
      if (matchedItem.submenu) {
        const matchedSubitem = matchedItem.submenu.find((subitem) =>
          url.startsWith(subitem.route)
        );
        this.currentPage = matchedSubitem ? matchedSubitem.id : matchedItem.id;
        this.submenus[matchedItem.id] = true;
      } else {
        this.currentPage = matchedItem.id;
      }
    } else if (url === '/' || url.startsWith('/home')) {
      this.currentPage = 'home';
    } else {
      this.currentPage = 'home';
    }
  }

  logout() {
    this._authService.logout();
  }

  getActive(page: string) {
    return (
      this.currentPage.startsWith(page) && (!this.isMobile || !this.collapsed)
    );
  }
}
