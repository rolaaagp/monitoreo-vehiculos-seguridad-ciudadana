import { Component, Input } from '@angular/core';
import { LucideIconsModule } from '@shared/lucide/lucide.module';

@Component({
  selector: 'app-icon',
  standalone: true,
  imports: [LucideIconsModule],
  templateUrl: './icon.component.html',
  styleUrl: './icon.component.css',
})
export class IconComponent {
  @Input() name!: string;
  @Input() size?: number | string;
  @Input() class?: string;
}
