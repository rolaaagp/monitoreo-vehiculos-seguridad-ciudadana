import { AfterViewInit, Component, inject, OnInit } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AuthService } from '@services/auth/auth.service';
import { UsersService } from '@services/users/users.service';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  standalone: true,
  imports: [CommonModule, RouterModule],
})
export class LoginComponent implements OnInit, AfterViewInit {
  private _authService = inject(AuthService);
  private _userService = inject(UsersService);
  private _spinnerService = inject(NgxSpinnerService);

  ngOnInit(): void {
    const token = this._userService.storedGoogleTokenKey;

    if (token) {
      this._spinnerService.show();
      this._authService.loginRedirect();
      this._spinnerService.hide();
      return;
    }
  }

  ngAfterViewInit(): void {
    this._authService.loadGoogleScript().then(() => {
      this._authService.initGoogleLogin(
        this._authService.handleGoogleCredentialResponse.bind(this._authService)
      );
    });
  }
}
