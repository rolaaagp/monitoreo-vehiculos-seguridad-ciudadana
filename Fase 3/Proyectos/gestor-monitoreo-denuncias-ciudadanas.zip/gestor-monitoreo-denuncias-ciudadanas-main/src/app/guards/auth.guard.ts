import { Injectable } from '@angular/core';
import {
  CanActivate,
  CanActivateChild,
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
  Router,
} from '@angular/router';
import { UsersService } from '@services/users/users.service';
import { PROFILES } from '@shared/constants/profiles.constants';

@Injectable({ providedIn: 'root' })
export class AuthGuard implements CanActivate, CanActivateChild {
  constructor(
    private readonly _router: Router,
    private readonly _users: UsersService
  ) {}

  private async check(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Promise<boolean> {
    await this._users.ensureLoaded();
    const user = this._users.currentUser;

    if ([PROFILES.CIUDADANO].includes(user?.perfil.id as number)) {
      this._users.logout();
      this._router.navigate(['/login'], {
        queryParams: { returnUrl: state.url },
      });
      return false;
    }

    if (user || this._users.storedGoogleTokenKey) return true;

    this._router.navigate(['/login'], {
      queryParams: { returnUrl: state.url },
    });
    return false;
  }

  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Promise<boolean> {
    return this.check(route, state);
  }

  canActivateChild(
    childRoute: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Promise<boolean> {
    return this.check(childRoute, state);
  }
}
