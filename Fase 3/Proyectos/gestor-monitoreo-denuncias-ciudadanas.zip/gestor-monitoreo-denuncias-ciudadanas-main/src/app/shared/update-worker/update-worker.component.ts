import { Component, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-update-worker',
  imports: [],
  templateUrl: './update-worker.component.html',
  styleUrl: './update-worker.component.css',
})
export class UpdateWorkerComponent {
  @Output() update: EventEmitter<string> = new EventEmitter();
}
