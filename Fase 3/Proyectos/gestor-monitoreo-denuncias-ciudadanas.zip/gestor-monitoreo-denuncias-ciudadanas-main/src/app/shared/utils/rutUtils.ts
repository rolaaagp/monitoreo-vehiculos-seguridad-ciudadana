export function validateRUN(rut: string): boolean {
  try {
    const clean = rut.replace(/\./g, '').replace(/-/g, '');
    const body = clean.slice(0, -1);
    const dvInput = clean.slice(-1).toUpperCase();

    let sum = 0;
    let factor = 2;

    for (let i = body.length - 1; i >= 0; i--) {
      sum += parseInt(body[i], 10) * factor;
      factor = factor < 7 ? factor + 1 : 2;
    }

    const dvCalc = 11 - (sum % 11);
    let expectedDv: string;
    if (dvCalc === 11) expectedDv = '0';
    else if (dvCalc === 10) expectedDv = 'K';
    else expectedDv = String(dvCalc);

    return dvInput === expectedDv;
  } catch {
    return false;
  }
}
