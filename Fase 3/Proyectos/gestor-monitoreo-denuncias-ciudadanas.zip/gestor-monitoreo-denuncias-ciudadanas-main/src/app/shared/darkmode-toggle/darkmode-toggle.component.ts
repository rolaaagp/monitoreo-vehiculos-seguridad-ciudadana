import { CommonModule } from '@angular/common';
import { Component, OnInit, inject } from '@angular/core';
import { IconComponent } from 'src/app/components/icon/icon.component';
import { ThemeService } from 'src/app/services/theme/theme.service';

@Component({
  selector: 'app-darkmode-toggle',
  templateUrl: './darkmode-toggle.component.html',
  imports: [CommonModule, IconComponent],
})
export class DarkmodeToggleComponent implements OnInit {
  private themeService = inject(ThemeService);
  darkMode = false;

  ngOnInit() {
    this.themeService.init();
    this.darkMode = this.themeService.theme() === 'dark';
  }

  toggleTheme() {
    this.themeService.toggleTheme();
    this.darkMode = this.themeService.theme() === 'dark';
  }
  
  
}
