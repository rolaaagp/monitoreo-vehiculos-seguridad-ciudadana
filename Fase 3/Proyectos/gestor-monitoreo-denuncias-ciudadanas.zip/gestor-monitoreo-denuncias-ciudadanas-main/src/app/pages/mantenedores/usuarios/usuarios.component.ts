import {
  Component,
  OnInit,
  ViewChild,
  ElementRef,
  signal,
  WritableSignal,
} from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
import { finalize, firstValueFrom, retry } from 'rxjs';
import { ToastrService } from '@services/toastr/toastr.service';
import { UsersService } from '@services/users/users.service';
import { CommonsService } from '@services/commons/commons.service';
import { UsersList, Profile } from '@interfaces/user.interface';
import { IconComponent } from '@components/icon/icon.component';
import { PaginationComponent } from '@shared/pagination/pagination.component';
import { BreadcrumbComponent } from '@shared/breadcrumb/breadcrumb.component';
import { CommonModule } from '@angular/common';
import { PROFILES } from '@shared/constants/profiles.constants';

@Component({
  selector: 'app-usuarios',
  templateUrl: './usuarios.component.html',
  styleUrls: ['./usuarios.component.css'],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    BreadcrumbComponent,
    PaginationComponent,
    IconComponent,
  ],
})
export class UsuariosComponent implements OnInit {
  @ViewChild('modalAgregar') modalAgregar!: ElementRef<HTMLDialogElement>;
  @ViewChild('modalEditar') modalEditar!: ElementRef<HTMLDialogElement>;

  title = 'Listado';
  breadcrumbItems = [
    { label: 'Home', url: '/home', canClick: true },
    { label: 'Usuarios', url: '/modulo-usuarios', canClick: false },
    { label: this.title, canClick: false },
  ];

  users: WritableSignal<UsersList[]> = signal([]);

  currentUserId!: number;

  profiles!: Profile[];
  itemEdit: UsersList | null = null;

  form: FormGroup;
  formEdit: FormGroup;

  currentPage = 1;
  totalPages = 10;
  itemsPerPage = 5;

  isSpinnerVisible = signal(false);

  constructor(
    private fb: FormBuilder,
    private spinner: NgxSpinnerService,
    private toastr: ToastrService,
    private usersService: UsersService,
    private commonsService: CommonsService
  ) {
    this.form = this.fb.group({
      run: [''],
      fullname: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      telefono: ['', Validators.required],
      perfiles_id: ['', Validators.required],
    });

    this.formEdit = this.fb.group({
      run: [''],
      fullname: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      telefono: ['', Validators.required],
      perfiles_id: ['', Validators.required],
    });
  }

  async ngOnInit() {
    this.showSpinner();
    await this.getProfiles();
    await Promise.all([this.getAll(), this.setUserId()]);
    this.hideSpinner();
  }

  setUserId() {
    this.currentUserId = this.usersService.currentUser?.id as number;
  }

  showSpinner() {
    this.isSpinnerVisible.set(true);
    this.spinner.show();
  }

  hideSpinner() {
    this.isSpinnerVisible.set(false);
    this.spinner.hide();
  }

  openModalAgregar() {
    this.modalAgregar.nativeElement.showModal();
  }

  closeModalAgregar() {
    this.modalAgregar.nativeElement.close();
    this.form.reset();
  }

  openModalEditar(user: UsersList) {
    this.itemEdit = user;
    this.formEdit.patchValue({
      run: user.run,
      fullname: user.fullname,
      email: user.email,
      telefono: user.telefono,
      perfiles_id: user.perfil.id,
    });
    this.modalEditar.nativeElement.showModal();
  }

  closeModalEditar() {
    this.modalEditar.nativeElement.close();
    this.formEdit.reset();
  }

  async getProfiles(): Promise<void> {
    try {
      const res = await firstValueFrom(
        this.commonsService
          .getOptions<Profile[]>({ type: 'perfiles' })
          .pipe(retry(1))
      );
      this.profiles = res.data;
    } catch (err) {
      console.error(err);
    }
  }

  async getAll(): Promise<void> {
    try {
      console.debug('Profiles available:', this.profiles);

      const res = await firstValueFrom(
        this.usersService.getListUsersGestor({
          page: this.currentPage,
          limit: this.itemsPerPage,
        })
      );

      const data = res.data.items.map((item) => {
        const profile = this.profiles.find(
          (profile) => profile.id === item.perfiles_id
        ) as Profile;
        return {
          ...item,
          perfil: profile,
          perfiles_id: profile?.id,
          canChangeStatus: item.id !== this.currentUserId,
          canEdit: item.id !== this.currentUserId,
        };
      });

      this.users.set(data);
      this.totalPages = res.data.pagination?.totalPages || 1;
    } catch (err) {
      console.error(err);
    }
  }

  save() {
    console.debug(this.form.value);
    if (
      !this.form.valid ||
      this.getIsInvalidProfileSelected({ type: 'create' })
    )
      return;
    this.showSpinner();
    this.usersService
      .createUser(this.form.value)
      .pipe(finalize(() => this.hideSpinner()))
      .subscribe({
        next: () => {
          this.getAll();
          this.toastr.showSuccess('Usuario creado correctamente');
          this.closeModalAgregar();
        },
        error: (err) => console.error(err),
      });
  }

  edit() {
    if (!this.formEdit.valid || !this.itemEdit || this.getIsInvalidProfileSelected({ type: 'edit' })) return;
    this.showSpinner();
    const payload = { ...this.formEdit.value, id: this.itemEdit.id };
    this.usersService
      .updateUser(payload)
      .pipe(finalize(() => this.hideSpinner()))
      .subscribe({
        next: () => {
          this.getAll();
          this.toastr.showSuccess('Usuario editado correctamente');
          this.closeModalEditar();
        },
        error: (err) => console.error(err),
      });
  }

  getIsInvalidProfileSelected(data: { type: 'edit' | 'create' }) {
    return [PROFILES.ADMIN, PROFILES.CIUDADANO].includes(
      Number(
        (data.type === 'edit' ? this.formEdit : this.form).get('perfiles_id')
          ?.value
      )
    );
  }

  changeStatus(item: UsersList) {
    this.showSpinner();
    this.usersService
      .changeStatusUser({
        id: item.id,
        run: item.run as string,
      })
      .pipe(finalize(() => this.hideSpinner()))
      .subscribe({
        next: () => {
          this.users.update((users) =>
            users.map((u) =>
              u.id === item.id ? { ...u, activo: !u.activo } : u
            )
          );
          this.toastr.showSuccess('Usuario editado correctamente');
          this.closeModalEditar();
        },
        error: (err) => console.error(err),
      });
  }

  onPageChange(page: number) {
    this.currentPage = page;
    this.getAll();
  }

  onItemsPerPageChange(items: number) {
    this.itemsPerPage = items;
    this.currentPage = 1;
    this.getAll();
  }

  onRunInput(event: any, isCreate: boolean) {
    let value = event.target.value
      .toUpperCase()
      .replace(/[^0-9K]/g, '')
      .replace(/-/g, '');
    let runPart = value.slice(0, -1);
    let dvPart = value.slice(-1);
    let formatted = value.length > 1 ? `${runPart}-${dvPart}` : value;
    event.target.value = formatted;

    const control = isCreate ? this.form.get('run') : this.formEdit.get('run');
    control?.setValue(formatted, { emitEvent: false });

    if (runPart && dvPart) {
      control?.setErrors(
        this.validateRun(runPart, dvPart) ? null : { invalidRun: true }
      );
    } else {
      control?.setErrors(null);
    }
  }

  validateRun(run: string, dv: string): boolean {
    if (!/^\d+$/.test(run)) return false;
    let suma = 0;
    let multiplicador = 2;
    for (let i = run.length - 1; i >= 0; i--) {
      suma += parseInt(run[i], 10) * multiplicador;
      multiplicador = multiplicador < 7 ? multiplicador + 1 : 2;
    }
    const resto = 11 - (suma % 11);
    const dvEsperado =
      resto === 11 ? '0' : resto === 10 ? 'K' : resto.toString();
    return dvEsperado === dv.toUpperCase();
  }
}
