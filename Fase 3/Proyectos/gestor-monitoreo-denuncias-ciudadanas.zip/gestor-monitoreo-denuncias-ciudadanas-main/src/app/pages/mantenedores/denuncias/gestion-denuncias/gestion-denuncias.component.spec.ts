import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GestionDenunciasComponent } from './gestion-denuncias.component';

describe('GestionDenunciasComponent', () => {
  let component: GestionDenunciasComponent;
  let fixture: ComponentFixture<GestionDenunciasComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [GestionDenunciasComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GestionDenunciasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
