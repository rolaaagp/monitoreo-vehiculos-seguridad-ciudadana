import { CommonModule } from '@angular/common';
import {
  ChangeDetectorRef,
  Component,
  ElementRef,
  OnInit,
  signal,
  ViewChild,
} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { IconComponent } from '@components/icon/icon.component';
import {
  IDenunciaFull,
  IDerivacion,
  IEstadoDenuncia,
  IEvidencia,
  IFamilia,
  IHistorialGestion,
  IRequerimiento,
  ITipoDerivacion,
  ITipoPrioridad,
} from '@interfaces/denuncia.interface';
import { DenunciaService } from '@services/denuncias/denuncias.service';
import { ToastrService } from '@services/toastr/toastr.service';
import { BreadcrumbComponent } from '@shared/breadcrumb/breadcrumb.component';
import { STATUS_DENUNCIA } from '@shared/constants/status.contants';
import { NgxSpinnerService } from 'ngx-spinner';
import { finalize, firstValueFrom, retry } from 'rxjs';
import { GoogleMapsModule } from '@angular/google-maps';
import { CommonsService } from '@services/commons/commons.service';
import { ClickOutsideDirective } from '@directives/clickOutside.directive';
import { UsersService } from '@services/users/users.service';
import { PROFILES } from '@shared/constants/profiles.constants';
import { ESTADOS_DERIVACION } from '@shared/constants/constants';
import { User } from '@interfaces/user.interface';
import {
  FormBuilder,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';

@Component({
  selector: 'app-gestion-denuncias',
  standalone: true,
  templateUrl: './gestion-denuncias.component.html',
  styleUrl: './gestion-denuncias.component.css',
  imports: [
    BreadcrumbComponent,
    CommonModule,
    IconComponent,
    GoogleMapsModule,
    ClickOutsideDirective,
    FormsModule,
    ReactiveFormsModule,
  ],
})
export class GestionDenunciasComponent implements OnInit {
  @ViewChild('modalAgregar') modalAgregar!: ElementRef<HTMLDialogElement>;
  @ViewChild('modalDerivar') modalDerivar!: ElementRef<HTMLDialogElement>;
  @ViewChild('modalVerDerivacion')
  modalVerDerivacion!: ElementRef<HTMLDialogElement>;

  title = 'Gestión de Denuncias';
  breadcrumbItems = [
    { label: 'Home', url: '/home', canClick: true },
    { label: 'Denuncias', url: '/modulo-denuncias', canClick: true },
    { label: this.title, canClick: true },
  ];

  denuncia!: IDenunciaFull;
  denunciaId: number = 0;

  user!: User;

  center: google.maps.LatLngLiteral | null = null;
  zoom = 15;
  mapReady = false;

  estadosDenuncia!: IEstadoDenuncia[];
  familias!: IFamilia[];
  requerimientos!: IRequerimiento[];
  prioridades: ITipoPrioridad[] = [];
  usersAsignar!: User[];
  tiposDerivacion: ITipoDerivacion[] = [];

  dropdowns = {
    estado: false,
    requerimiento: false,
    familia: false,
    asignar: false,
    otroRequerimiento: false,
    prioridad: false,
    prioridadOptions: false,
    derivar: false,
  };

  nuevoRequerimiento = {
    nombre: '',
    prioridad: null as ITipoPrioridad | null,
  };

  estadoACambiar: IEstadoDenuncia | undefined = undefined;

  generalLoading = false;

  formDerivar: FormGroup;

  isSpinnerVisible = signal(false);

  selectedDerivacion: IDerivacion | null = null;

  constructor(
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private readonly _spinner: NgxSpinnerService,
    private readonly _toastr: ToastrService,
    private readonly _denunciaService: DenunciaService,
    private readonly _userService: UsersService,
    private readonly _commonService: CommonsService,
    private readonly _cdr: ChangeDetectorRef
  ) {
    this.formDerivar = this.fb.group({
      tipo_derivacion: ['', Validators.required],
      observacion: [''],
    });
  }

  get requerimientosDisplay(): { nombre: string; prioridad: string }[] {
    if (!this.denuncia) return [];
    const requerimientos = [
      this.denuncia.requerimiento,
      ...(this.denuncia.requerimiento_adicional_denuncia || []),
    ].filter((r) => r);
    return requerimientos.map((r) => ({
      nombre: r!.nombre,
      prioridad: r!.tipo_prioridad?.nombre || 'Sin asignar',
    }));
  }

  get userId(): number {
    return this.user.id;
  }

  get usuarioNoPuedeEditar(): boolean {
    const perfilesQueNoEditan = [PROFILES.DIRECTOR, PROFILES.INSPECTOR];

    const usuarioNoPuedeEditar = perfilesQueNoEditan.includes(
      this.user.perfil.id
    );
    return usuarioNoPuedeEditar;
  }

  get deshabilitarEditar(): boolean {
    const statusId = this.denuncia?.estado?.id as number;
    const esDenunciaRechazada = statusId === STATUS_DENUNCIA.RECHAZADA;

    return this.usuarioNoPuedeEditar || esDenunciaRechazada;
  }

  async ngOnInit() {
    this.generalLoading = true;
    this.route.queryParams.subscribe((params) => {
      this.denunciaId = Number(params['id']);
      if (this.denunciaId) {
        this.cargarDenuncia();
      } else {
        this._toastr.showError('No se ha proporcionado un ID válido');
        this.router.navigate(['/modulo-denuncias']);
      }
    });

    this.user = this._userService.currentUser as User;

    await this.getOptions();
    setTimeout(() => {
      this.generalLoading = false;
    }, 500);
  }

  cargarDenuncia(): void {
    this._spinner.show();
    this._denunciaService
      .getById(this.denunciaId)
      .pipe(retry(1))
      .subscribe({
        next: (res) => {
          this.denuncia = res.data;

          if (this.denuncia?.latitud && this.denuncia?.longitud) {
            setTimeout(() => {
              this.center = {
                lat: Number(this.denuncia?.latitud) || 0,
                lng: Number(this.denuncia?.longitud) || 0,
              };
              this.mapReady = true;
            }, 500);
          } else {
            this.center = null;
            this.mapReady = false;
          }

          setTimeout(() => {
            this._spinner.hide();
          }, 500);
        },
        error: (err: any) => {
          this._spinner.hide();
          this.generalLoading = false;
          this._toastr.showError('No se pudo cargar la denuncia');
          console.error(err);
          this.router.navigate(['/modulo-denuncias']);
        },
      });
  }

  async getOptions() {
    const [
      status,
      familias,
      requerimientos,
      prioridades,
      users,
      tipos_derivacion,
    ] = await Promise.all([
      firstValueFrom(
        this._commonService.getOptions<IEstadoDenuncia[]>({ type: 'estados' })
      ),
      firstValueFrom(
        this._commonService.getOptions<IFamilia[]>({ type: 'familias' })
      ),
      firstValueFrom(
        this._commonService.getOptions<IRequerimiento[]>({
          type: 'requerimientos',
        })
      ),
      firstValueFrom(
        this._commonService.getOptions<ITipoPrioridad[]>({
          type: 'tipos_prioridad',
        })
      ),
      firstValueFrom(
        this._userService
          .getAllByProfile({ profile: PROFILES.CONDUCTOR })
          .pipe(retry(1))
      ),
      firstValueFrom(
        this._commonService.getOptions<ITipoDerivacion[]>({
          type: 'tipos_derivacion',
        })
      ),
    ]);

    this.estadosDenuncia = status.data;
    this.familias = familias.data;
    this.requerimientos = requerimientos.data;
    this.prioridades = prioridades.data;
    this.usersAsignar = users.data;
    this.tiposDerivacion = tipos_derivacion.data;
  }
  toggleDropdown(key: keyof typeof this.dropdowns) {
    console.debug('toggleDropdown called with key:', key);
    console.debug('deshabilitarEditar:', this.deshabilitarEditar);
    console.debug('dropdowns antes:', this.dropdowns);

    if (
      (['requerimiento', 'familia', 'asignar', 'estado'].includes(key) &&
        this.deshabilitarEditar) ||
      this.usuarioNoPuedeEditar
    ) {
      console.debug('Edición deshabilitada, no se abre:', key);
      return;
    }

    if (key === 'otroRequerimiento') {
      this.dropdowns = {
        ...this.dropdowns,
        otroRequerimiento: !this.dropdowns.otroRequerimiento,
        prioridad: true,
        prioridadOptions: false,
      };
      console.debug(
        'otroRequerimiento toggled:',
        this.dropdowns.otroRequerimiento
      );
      console.debug('dropdowns después:', this.dropdowns);
      return;
    }

    if (key === 'prioridadOptions') {
      this.dropdowns = {
        ...this.dropdowns,
        prioridadOptions: !this.dropdowns.prioridadOptions,
      };
      console.debug(
        'prioridadOptions toggled:',
        this.dropdowns.prioridadOptions
      );
      console.debug('dropdowns después:', this.dropdowns);
      return;
    }

    this.dropdowns = {
      ...this.dropdowns,
      ...Object.keys(this.dropdowns).reduce((acc, k) => {
        if (
          k !== key &&
          !['otroRequerimiento', 'prioridad', 'prioridadOptions'].includes(k)
        ) {
          acc[k as keyof typeof this.dropdowns] = false;
        }
        return acc;
      }, {} as typeof this.dropdowns),
      [key]: !this.dropdowns[key],
    };

    console.debug('dropdowns finales:', this.dropdowns);
  }

  closeDropdown(key: keyof typeof this.dropdowns) {
    this.dropdowns[key] = false;
  }

  closeAllRequerimientoOptions() {
    this.dropdowns.requerimiento = false;
    this.dropdowns.otroRequerimiento = false;
    this.dropdowns.prioridad = false;
    this.dropdowns.prioridadOptions = false;
    this.resetNuevoRequerimiento();
  }

  resetNuevoRequerimiento() {
    this.nuevoRequerimiento.nombre = '';
    this.nuevoRequerimiento.prioridad = null;
  }

  onInputNuevoRequerimiento() {
    if (this.nuevoRequerimiento.nombre.trim()) {
      this.dropdowns.prioridad = true;
    }
  }

  onSubmitNuevoRequerimiento(event: Event) {
    event.preventDefault();
    this.onInputNuevoRequerimiento();
  }

  updateEstado(estado: IEstadoDenuncia) {
    if (
      [STATUS_DENUNCIA.RECHAZADA, STATUS_DENUNCIA.APROBADA].includes(estado.id)
    ) {
      this.estadoACambiar = estado;
      this.modalAgregar.nativeElement.showModal();
    } else {
      this.confirmarCambioEstado(estado);
    }
  }

  confirmarCambioEstado(estado?: IEstadoDenuncia) {
    const estadoFinal = estado || this.estadoACambiar;
    this.modalAgregar.nativeElement.close();
    this._spinner.show();
    this._denunciaService
      .cambiarEstado({
        id: this.denunciaId,
        estado_id: estadoFinal?.id as number,
        user_id: this.userId,
      })
      .pipe(finalize(() => this._spinner.hide()))
      .subscribe({
        next: (res) => {
          this.denuncia.estado = estadoFinal!;
          this.settearArrayHistorialGestiones(res.data);
        },
        error: (err) => console.error(err),
      });
  }

  updateRequerimiento(req: IRequerimiento) {
    this.closeAllRequerimientoOptions();
    this._spinner.show();
    this._denunciaService
      .cambiarRequerimiento({
        id: this.denunciaId,
        requerimiento_id: req.id,
        user_id: this.userId,
      })
      .pipe(
        retry(1),
        finalize(() => this._spinner.hide())
      )
      .subscribe({
        next: (res) => {
          this.denuncia.requerimiento = req;
          this.settearArrayHistorialGestiones(res.data);
        },
        error: (err) => console.error(err),
      });
  }

  selectPrioridad(prioridad: ITipoPrioridad) {
    this.nuevoRequerimiento.prioridad = prioridad;
    this.dropdowns.prioridadOptions = false;
  }

  addNuevoRequerimiento() {
    if (
      !this.nuevoRequerimiento.nombre.trim() ||
      !this.nuevoRequerimiento.prioridad
    )
      return;

    this._spinner.show();
    const payload = {
      denuncia_id: this.denunciaId,
      nombre_requerimiento: this.nuevoRequerimiento.nombre,
      tipo_prioridad_id: this.nuevoRequerimiento.prioridad.id,
      user_id: this.userId,
    };

    console.debug('Payload nuevo requerimiento:', payload);

    this._denunciaService
      .agregarRequerimientoAdic(payload)
      .pipe(finalize(() => this._spinner.hide()))
      .subscribe({
        next: (res) => {
          this.settearArrayHistorialGestiones(res.data.historial);
          this.denuncia.requerimiento_adicional_denuncia?.push(
            res.data.requerimiento
          );
        },
        error: (err) => console.error(err),
      });

    this.closeAllRequerimientoOptions();
  }

  cancelarNuevoRequerimiento() {
    this.closeAllRequerimientoOptions();
  }

  updateFamilia(familia: IFamilia) {
    this.closeDropdown('familia');
    this._spinner.show();
    this._denunciaService
      .cambiarFamilia({
        id: this.denunciaId,
        familia_id: familia.id,
        user_id: this.userId,
      })
      .pipe(
        retry(1),
        finalize(() => this._spinner.hide())
      )
      .subscribe({
        next: (res) => {
          this.denuncia.familia = familia;
          this.settearArrayHistorialGestiones(res.data);
        },
        error: (err) => console.error(err),
      });
  }

  asignar(user: User) {
    this.closeDropdown('asignar');
    this._spinner.show();
    this._denunciaService
      .asignar({
        id: this.denunciaId,
        user_id_asignado: user.id,
        user_id: this.userId,
      })
      .pipe(
        retry(1),
        finalize(() => this._spinner.hide())
      )
      .subscribe({
        next: (res) => {
          this.denuncia.user_asignado = user;
          this.settearArrayHistorialGestiones(res.data);
        },
        error: (err) => console.error(err),
      });
  }

  getFormattedFolio(): string {
    if (!this.denuncia) return '';
    const year = new Date(this.denuncia.fecha).getFullYear();
    return `DEN-${year}-${this.denuncia.id.toString().padStart(3, '0')}`;
  }

  getColorStatus(estadoId: number | undefined): string {
    if (!estadoId) return 'bg-warning';
    const colorMap: Record<number, string> = {
      [STATUS_DENUNCIA.INGRESADA]: 'bg-warning',
      [STATUS_DENUNCIA.EN_PROCESO]: 'bg-progress',
      [STATUS_DENUNCIA.RESUELTO]: 'bg-success',
    };
    return colorMap[estadoId] || 'bg-warning';
  }

  download(key: string) {
    this._spinner.show();
    this._commonService
      .getSignedUrl({ key, responseContentDisposition: 'attachment' })
      .pipe(
        retry(1),
        finalize(() => this._spinner.hide())
      )
      .subscribe({
        next: (res) => window.open(res.data.url, '_blank'),
        error: (err) => {},
      });
  }

  getNombreEvidencia(evidencia: IEvidencia): string {
    return evidencia.key_s3 ? evidencia.key_s3.split('/').pop() || '' : '';
  }

  getTipoArchivo(evidencia: IEvidencia): string {
    if (!evidencia.key_s3) return '';
    const extension = evidencia.key_s3.split('.').pop()?.toLowerCase();
    if (!extension) return '';
    if (['jpg', 'jpeg', 'png', 'gif', 'webp'].includes(extension))
      return 'imagen';
    if (['mp4', 'mov', 'avi', 'mkv', 'webm'].includes(extension))
      return 'video';
    if (['mp3', 'wav', 'ogg', 'm4a'].includes(extension)) return 'audio';
    if (['pdf', 'doc', 'docx', 'xls', 'xlsx', 'txt'].includes(extension))
      return 'documento';
    return 'otro';
  }

  volver(): void {
    this.router.navigate(['/modulo-denuncias']);
  }

  gestionarAprobarORechazar() {
    const statusId = this.denuncia?.estado?.id as number;
    if (
      [STATUS_DENUNCIA.APROBADA, STATUS_DENUNCIA.RECHAZADA].includes(statusId)
    ) {
      if (statusId === STATUS_DENUNCIA.APROBADA) {
        console.debug('Denuncia estado: Aprobada');
      }

      if (statusId === STATUS_DENUNCIA.RECHAZADA) {
        console.debug('Denuncia estado: Rechazada');
      }
    }
  }
  onFilesSelected(event: Event) {
    const input = event.target as HTMLInputElement;
    if (!input.files || !this.denuncia) return;
    this._spinner.show();
    const files = Array.from(input.files);

    const evidencias = files.map((file) => {
      const reader = new FileReader();
      return new Promise<{
        filename: string;
        base64Data: string;
        contentType: string;
      }>((resolve) => {
        reader.onload = () => {
          const base64 = (reader.result as string).split(',')[1];
          resolve({
            filename: file.name,
            base64Data: base64,
            contentType: file.type,
          });
        };
        reader.readAsDataURL(file);
      });
    });

    Promise.all(evidencias).then((archivos) => {
      this._denunciaService
        .subirEvidenciaDenuncia({
          denuncia_id: this.denuncia.id,
          evidencias: archivos,
        })
        .pipe(finalize(() => this._spinner.hide()))
        .subscribe({
          next: (res) => {
            res.data.forEach((file) => {
              this.denuncia.evidencia?.push(file);
            });
          },
          error: (err) => {
            console.error('Error subiendo archivo:', err);
            this._toastr.showError('Error subiendo archivo');
            this._spinner.hide();
          },
        });
    });
  }

  onVisibilidadChange(visible: boolean) {
    this._spinner.show();
    console.log('Visibilidad seleccionada:', visible);

    this._denunciaService
      .cambiarVisibilidadVecino({
        id: this.denunciaId,
        visible,
        user_id: this.userId,
      })
      .pipe(
        retry(1),
        finalize(() => this._spinner.hide())
      )
      .subscribe({
        next: (res) => {
          this.settearArrayHistorialGestiones(res.data);
        },
        error: (err) => console.error(err),
      });
  }

  settearArrayHistorialGestiones(historial: any) {
    const hist = historial.historial || historial;
    const item: IHistorialGestion = {
      detalle: hist.detalle || 'Sin detalle',
      fecha: hist.fecha
        ? new Date(hist.fecha).toISOString()
        : new Date().toISOString(),
      accion: hist.accion || 'Sin acción',
      denuncias_id: hist.denuncias_id || this.denunciaId,
      users_id: hist.users_id || this.userId,
      id: hist.id || Math.floor(Math.random() * 1000000), // ID temporal si no existe
    };

    this.denuncia.historial_gestiones = [
      ...(this.denuncia.historial_gestiones || []),
      item,
    ];

    this._cdr.detectChanges();
  }

  toggleModalDerivar(props: { open: boolean }) {
    props.open
      ? this.modalDerivar.nativeElement.showModal()
      : this.modalDerivar.nativeElement.close();
  }

  showSpinner() {
    this.isSpinnerVisible.set(true);
    this._spinner.show();
  }
  hideSpinner() {
    this.isSpinnerVisible.set(false);
    this._spinner.hide();
  }
  derivar() {
    this.showSpinner();
    const form = this.formDerivar.value;
    this._denunciaService
      .derivar({
        denuncia_id: this.denunciaId,
        detalle: form.observacion,
        tipo_derivacion_id: Number(form.tipo_derivacion),
        estados_derivacion_id: ESTADOS_DERIVACION.DERIVADA,
        user_id: this.userId,
      })
      .pipe(
        retry(1),
        finalize(() => {
          this.hideSpinner();
          this.toggleModalDerivar({ open: false });
        })
      )
      .subscribe({
        next: (res) => {
          this.settearArrayHistorialGestiones(res.data);
          this.denuncia.derivaciones = [
            ...(this.denuncia.derivaciones || []),
            res.data.derivacion,
          ];
          this.formDerivar.reset({ tipo_derivacion: '', observacion: '' });
        },
        error: (err) => console.error(err),
      });
  }

  openDerivacionModal(derivacion: IDerivacion) {
    this.selectedDerivacion = derivacion;
    this.modalVerDerivacion.nativeElement.showModal();
  }
}
