import { CommonModule } from '@angular/common';
import {
  Component,
  ElementRef,
  OnInit,
  signal,
  ViewChild,
  WritableSignal,
} from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
import { finalize, retry } from 'rxjs';
import { ToastrService } from '@services/toastr/toastr.service';
import { BreadcrumbComponent } from '@shared/breadcrumb/breadcrumb.component';
import { PaginationComponent } from '@shared/pagination/pagination.component';
import { DenunciaService } from '@services/denuncias/denuncias.service';
import {
  DenunciaList,
  RequestCrearDenuncia,
} from '@interfaces/denuncia.interface';
import { STATUS_DENUNCIA } from '@shared/constants/status.contants';
import { IconComponent } from '@components/icon/icon.component';
import { Router } from '@angular/router';
import { HasProfileDirective } from '@directives/hasProfile.directive';
import { PROFILES } from '@shared/constants/profiles.constants';
import { User } from '@interfaces/user.interface';
import { UsersService } from '@services/users/users.service';

@Component({
  selector: 'app-denuncias',
  templateUrl: './denuncias.component.html',
  styleUrl: './denuncias.component.css',
  imports: [
    CommonModule,
    ReactiveFormsModule,
    BreadcrumbComponent,
    PaginationComponent,
    IconComponent,
    HasProfileDirective,
  ],
})
export class DenunciasComponent implements OnInit {
  @ViewChild('modalAgregar') modalAgregar!: ElementRef<HTMLDialogElement>;

  breadcrumbItems = [
    { label: 'Home', url: '/home', canClick: true },
    { label: 'Denuncias', url: '/modulo-denuncias', canClick: false },
    { label: 'Listado', canClick: true },
  ];

  evidencias: File[] = [];
  errores: Record<string, boolean> = {};
  showModal = false;
  enviando = false;

  denuncias: WritableSignal<DenunciaList[]> = signal([]);
  denunciaEdit: any | null = null;
  form: FormGroup;

  currentPage: number = 1; // Página actual
  totalPages: number = 10; // Total de páginas
  itemsPerPage: number = 5; // Elementos por página

  PROFILES = PROFILES;

  private userConectado: User | null = null;

  constructor(
    private fb: FormBuilder,
    private readonly _spinner: NgxSpinnerService,
    private readonly _toastr: ToastrService,
    private readonly _denunciaService: DenunciaService,
    private router: Router,
    private userService: UsersService
  ) {
    this.form = this.fb.group({
      ubicacion: ['', Validators.required],
      descripcion: ['', [Validators.required, Validators.minLength(10)]],
      fecha: ['', Validators.required],
      hora: ['', Validators.required],
    });
  }

  ngOnInit() {
    this.getAll();
    this.userConectado = this.userService.currentUser;
  }

  getFormattedFolio(item: DenunciaList): string {
    const year = new Date(item.fecha).getFullYear();
    return `DEN-${year}-${item.id.toString().padStart(3, '0')}`;
  }

  getAll() {
    this._spinner.show();
    this._denunciaService
      .getAll({ page: this.currentPage, limit: this.itemsPerPage })
      .pipe(
        retry(1),
        finalize(() => this._spinner.hide())
      )
      .subscribe({
        next: (res: any) => {
          this.denuncias.set(res.data.items);
          this.totalPages = res.data.pagination
            ? res.data.pagination.totalPages
            : 1;
        },
        error: (err: any) => {
          this._spinner.hide();
          this._toastr.showError(
            `No se ha podido obtener la información correctamente.`
          );
          console.error(err);
        },
      });
  }

  onPageChange(page: number) {
    this.currentPage = page;
    console.log(`Página cambiada a: ${this.currentPage}`);
    this.getAll();
  }

  onItemsPerPageChange(items: number) {
    this.itemsPerPage = items;
    this.currentPage = 1;
    console.log(`Items por página cambiados a: ${this.itemsPerPage}`);
    this.getAll();
  }

  getColorStatus(estadoId: number): string {
    const colorMap: Record<number, string> = {
      [STATUS_DENUNCIA.INGRESADA]: 'bg-warning',
      [STATUS_DENUNCIA.EN_PROCESO]: 'bg-progress',
      [STATUS_DENUNCIA.RESUELTO]: 'bg-success',
    };
    return colorMap[estadoId] || 'bg-warning';
  }

  verDetalle(item: DenunciaList): void {
    this.router.navigate(['modulo-denuncias/gestionar'], {
      queryParams: { id: item.id },
    });
  }

  validarFormulario(): boolean {
    this.errores = {};
    for (const key of Object.keys(this.form.controls)) {
      const control = this.form.get(key);
      if (control && control.invalid) this.errores[key] = true;
    }
    return this.form.valid;
  }

  onFilesSelected(event: Event) {
    const input = event.target as HTMLInputElement;
    if (input.files) {
      this.evidencias = Array.from(input.files);
    }
  }

  abrirModal() {
    if (this.validarFormulario()) {
      this.showModal = true;
    }
  }

  cerrarModal() {
    this.showModal = false;
  }

  async enviarDenuncia() {
    this.enviando = true;
    this.showModal = false;
    this._spinner.show();
    const form = this.form.value;

    const [year, month, day] = form.fecha.split('-').map(Number);
    const [hour, minute] = form.hora.split(':').map(Number);
    const fechaCompleta = new Date(year, month - 1, day, hour, minute);

    const evidenciasMap = await Promise.all(
      this.evidencias.map((file) => {
        return new Promise((resolve) => {
          const reader = new FileReader();
          reader.onload = () => {
            const base64 = (reader.result as string).split(',')[1];
            resolve({
              filename: file.name,
              base64Data: base64,
              contentType: file.type,
            });
          };
          reader.readAsDataURL(file);
        });
      })
    );

    const payload: RequestCrearDenuncia = {
      detalle: form.descripcion,
      ubicacion: form.ubicacion,
      evidencias: evidenciasMap as RequestCrearDenuncia['evidencias'],
      fecha_completa: fechaCompleta.toISOString(),
      latitud: -33.5854809,
      longitud: -70.7026671,
      user_id: this.userConectado?.id as number,
    };
    
    this._denunciaService
      .crearDenuncia(payload)
      .pipe(
        finalize(() => {
          this.form.reset();
          this.evidencias = [];
          this.enviando = false;
          this.showModal = false;
          this.modalAgregar.nativeElement.close();
          this._spinner.hide();
        })
      )
      .subscribe({
        next: (res) => {
          this._toastr.showSuccess('Denuncia registrada exitosamente.');
        },
        error: (err) => {
          console.error('Error al crear la denuncia:', err);
          this._toastr.showError(
            'Error al registrar la denuncia. Por favor, intente nuevamente.'
          );
        },
      });
  }

  abrirDialog() {
    this.modalAgregar.nativeElement.showModal();
  }

  cerrarDialog() {
    this.modalAgregar.nativeElement.close();
  }
}
