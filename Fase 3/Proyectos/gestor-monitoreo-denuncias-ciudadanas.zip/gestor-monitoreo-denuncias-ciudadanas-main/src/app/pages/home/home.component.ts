import { CommonModule } from '@angular/common';
import {
  Component,
  ElementRef,
  inject,
  OnInit,
  ViewChild,
} from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { HasProfileDirective } from '@directives/hasProfile.directive';
import {
  IDashboardResponse,
  RequestCrearDenuncia,
} from '@interfaces/denuncia.interface';
import { DenunciaService } from '@services/denuncias/denuncias.service';
import { ToastrService } from '@services/toastr/toastr.service';
import { PROFILES } from '@shared/constants/profiles.constants';
import { STATUS_DENUNCIA } from '@shared/constants/status.contants';
import { NgxSpinnerService } from 'ngx-spinner';
import { finalize, lastValueFrom } from 'rxjs';
import { FormGroup } from '@angular/forms';
import { User } from '@interfaces/user.interface';
import { UsersService } from '@services/users/users.service';
interface AccesoRapido {
  nombre: string;
  route: string;
  queryParam: any;
  profilesPermitted: number[];
}

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
  imports: [
    CommonModule,
    RouterModule,
    HasProfileDirective,
    ReactiveFormsModule,
  ],
})
export class HomeComponent implements OnInit {
  @ViewChild('chartCanvas') chartCanvas!: ElementRef<HTMLCanvasElement>;
  private _denunciaService = inject(DenunciaService);
  private _spinnerService = inject(NgxSpinnerService);
  @ViewChild('modalAgregar') modalAgregar!: ElementRef<HTMLDialogElement>;

  private userConectado: User | null = null;

  evidencias: File[] = [];
  errores: Record<string, boolean> = {};
  showModal = false;
  enviando = false;
  form: FormGroup;
  formEdit: FormGroup;

  STATUS_DENUNCIA = STATUS_DENUNCIA;

  estadosDashboard: IDashboardResponse[] = [];

  creadasHoy: number = 0;

  accesosRapidos: AccesoRapido[] = [
    {
      nombre: 'Ir a Módulo de Denuncias',
      route: '/modulo-denuncias',
      queryParam: {},
      profilesPermitted: [
        PROFILES.ADMIN,
        PROFILES.SUPERVISOR,
        PROFILES.COORDINADOR,
        PROFILES.OPERADOR_CCTV,
        PROFILES.DIRECTOR,
        PROFILES.INSPECTOR,
      ],
    },
    {
      nombre: 'Ir a Módulo de Usuarios',
      route: '/modulo-usuarios',
      queryParam: {},
      profilesPermitted: [
        PROFILES.SUPERVISOR,
        PROFILES.COORDINADOR,
        PROFILES.ADMIN,
      ],
    },
  ];

  statusStyles = {
    [STATUS_DENUNCIA.INGRESADA]: {
      border: 'border-blue-200',
      iconBg: 'bg-blue-100',
      iconColor: 'text-blue-600',
      numberColor: 'text-blue-600',
      svgPath:
        'M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z',
    },
    [STATUS_DENUNCIA.EN_PROCESO]: {
      border: 'border-yellow-200',
      iconBg: 'bg-yellow-100',
      iconColor: 'text-yellow-600',
      numberColor: 'text-yellow-600',
      svgPath: 'M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z',
    },
    [STATUS_DENUNCIA.APROBADA]: {
      border: 'border-purple-200',
      iconBg: 'bg-purple-100',
      iconColor: 'text-purple-600',
      numberColor: 'text-purple-600',
      svgPath: 'M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z',
    },
    [STATUS_DENUNCIA.RESUELTO]: {
      border: 'border-green-200',
      iconBg: 'bg-green-100',
      iconColor: 'text-green-600',
      numberColor: 'text-green-600',
      svgPath: 'M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z',
    },
    [STATUS_DENUNCIA.RECHAZADA]: {
      border: 'border-red-200',
      iconBg: 'bg-red-100',
      iconColor: 'text-red-600',
      numberColor: 'text-red-600',
      svgPath:
        'M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z',
    },
  };

  constructor(
    private fb: FormBuilder,
    private readonly _spinner: NgxSpinnerService,
    private readonly _toastr: ToastrService,
    private router: Router,
    private userService: UsersService
  ) {
    this.formEdit = this.fb.group({
      nombre: ['', Validators.required],
    });
    this.form = this.fb.group({
      ubicacion: ['', Validators.required],
      descripcion: ['', [Validators.required, Validators.minLength(10)]],
      fecha: ['', Validators.required],
      hora: ['', Validators.required],
    });
  }

  ngOnInit() {
    this._get();
    this.userConectado = this.userService.currentUser;
  }

  _get() {
    this._spinnerService.show();
    this._denunciaService
      .getDashboard()
      .pipe(finalize(() => this._spinnerService.hide()))
      .subscribe({
        next: (resp) => {
          console.log('Dashboard data:', resp.data);
          this.estadosDashboard = resp.data.top3PorEstado;
          this.creadasHoy = resp.data.creadasHoy ?? 0;
        },
        error: (err) => {
          console.error('Error fetching dashboard data:', err);
        },
      });
  }

  validarFormulario(): boolean {
    this.errores = {};
    for (const key of Object.keys(this.form.controls)) {
      const control = this.form.get(key);
      if (control && control.invalid) this.errores[key] = true;
    }
    return this.form.valid;
  }

  onFilesSelected(event: Event) {
    const input = event.target as HTMLInputElement;
    if (input.files) {
      this.evidencias = Array.from(input.files);
    }
  }

  abrirModal() {
    console.log('Formulario actual:', this.form.value);
    console.log('evidencias', this.evidencias);
    if (this.form.valid) {
      this.showModal = true;
    }
  }

  cerrarModal() {
    this.showModal = false;
  }

  async enviarDenuncia() {
    this.enviando = true;
    this.showModal = false;
    this._spinner.show();
    const form = this.form.value;

    const [year, month, day] = form.fecha.split('-').map(Number);
    const [hour, minute] = form.hora.split(':').map(Number);
    const fechaCompleta = new Date(year, month - 1, day, hour, minute);

    const evidenciasMap = await Promise.all(
      this.evidencias.map((file) => {
        return new Promise((resolve) => {
          const reader = new FileReader();
          reader.onload = () => {
            const base64 = (reader.result as string).split(',')[1];
            resolve({
              filename: file.name,
              base64Data: base64,
              contentType: file.type,
            });
          };
          reader.readAsDataURL(file);
        });
      })
    );

    const payload: RequestCrearDenuncia = {
      detalle: form.descripcion,
      ubicacion: form.ubicacion,
      evidencias: evidenciasMap as RequestCrearDenuncia["evidencias"],
      fecha_completa: fechaCompleta.toISOString(),
      latitud: -33.5854809,
      longitud: -70.7026671,
      user_id: this.userConectado?.id as number,
    };

    this._denunciaService
      .crearDenuncia(payload)
      .pipe(
        finalize(() => {
          this.form.reset();
          this.evidencias = [];
          this.enviando = false;
          this.showModal = false;
          this.modalAgregar.nativeElement.close();
          this._spinner.hide();
        })
      )
      .subscribe({
        next: (res) => {
          this._toastr.showSuccess('Denuncia registrada exitosamente.');
        },
        error: (err) => {
          console.error('Error al crear la denuncia:', err);
          this._toastr.showError(
            'Error al registrar la denuncia. Por favor, intente nuevamente.'
          );
        },
      });
  }

  abrirDialog() {
    this.modalAgregar.nativeElement.showModal();
  }

  cerrarDialog() {
    this.modalAgregar.nativeElement.close();
  }
}
