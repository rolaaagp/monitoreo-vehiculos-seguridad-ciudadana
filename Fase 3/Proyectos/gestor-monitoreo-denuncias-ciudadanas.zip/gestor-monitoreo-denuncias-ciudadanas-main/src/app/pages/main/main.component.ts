import { CommonModule } from '@angular/common';
import { Component, ElementRef, ViewChild } from '@angular/core';
import { NgxSpinnerModule } from 'ngx-spinner';
import { SidebarComponent } from '@components/sidebar/sidebar.component';
import { RouterModule } from '@angular/router';
import { HeaderComponent } from '@components/header/header.component';

@Component({
  selector: 'app-root',
  imports: [
    SidebarComponent,
    CommonModule,
    NgxSpinnerModule,
    RouterModule,
    HeaderComponent,
  ],
  templateUrl: './main.component.html',
  styleUrl: './main.component.css',
})
export class MainComponent {
  @ViewChild('sidebar') sidebar!: ElementRef;

  sidebarCollapsed = true;

  onSidebarToggle(state: boolean) {
    this.sidebarCollapsed = state;
  }
}
