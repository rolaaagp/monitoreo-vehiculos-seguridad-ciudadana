import { Routes } from '@angular/router';
import { AuthGuard } from './guards/auth.guard';

export const routes: Routes = [
  { path: '', loadComponent: () => import('./components/login/login.component').then(m => m.LoginComponent) },
  { path: 'login', loadComponent: () => import('./components/login/login.component').then(m => m.LoginComponent) },
  {
    path: '',
    loadComponent: () => import('./pages/main/main.component').then(m => m.MainComponent),
    canActivate: [AuthGuard],
    canActivateChild: [AuthGuard],
    children: [
      { path: 'home', pathMatch: 'full', loadComponent: () => import('./pages/home/home.component').then(m => m.HomeComponent) },
      { path: 'modulo-denuncias', loadComponent: () => import('./pages/mantenedores/denuncias/denuncias.component').then(m => m.DenunciasComponent) },
      { path: 'modulo-denuncias/gestionar', loadComponent: () => import('./pages/mantenedores/denuncias/gestion-denuncias/gestion-denuncias.component').then(m => m.GestionDenunciasComponent) },
      
      { path: 'modulo-usuarios', loadComponent: () => import('./pages/mantenedores/usuarios/usuarios.component').then(m => m.UsuariosComponent) },
    ]
  },
  { path: '**', loadComponent: () => import('./components/not-found/not-found.component').then(m => m.NotFoundComponent) }
];
