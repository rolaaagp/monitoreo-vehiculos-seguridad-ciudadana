import { TestBed } from '@angular/core/testing';

import { WebServiceWorker } from './web-service-worker.service';

describe('WebServiceWorkerService', () => {
  let service: WebServiceWorker;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(WebServiceWorker);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
