import { HttpClient, HttpParams } from '@angular/common/http';
import { booleanAttribute, inject, Injectable } from '@angular/core';
import {
  BehaviorSubject,
  firstValueFrom,
  retry,
  catchError,
  of,
  Observable,
} from 'rxjs';
import {
  CustomHttpInterface,
  CustomHttpInterfacePaginate,
  User,
  UsersList,
} from '@interfaces/index';
import { environment } from '@environments/environment';

@Injectable({
  providedIn: 'root',
})
export class UsersService {
  private readonly http = inject(HttpClient);

  private API_URL = `${environment.API_DOMAINS.BASE}/${environment.API_DOMAINS.USUARIOS_API}`;

  private userSubject = new BehaviorSubject<User | null>(null);
  public readonly currentUser$ = this.userSubject.asObservable();

  private readonly storageEmailKey = 'email';
  private readonly storageGoogleTokenKey = 'token';

  constructor() {
    const email = localStorage.getItem(this.storageEmailKey);
    if (email) this.loadUser(email);

    window.addEventListener('storage', (event) => {
      if (
        event.key === this.storageEmailKey ||
        event.key === this.storageGoogleTokenKey
      ) {
        const email = localStorage.getItem(this.storageEmailKey);
        const token = localStorage.getItem(this.storageGoogleTokenKey);

        if (!email && !token) {
          this.logout();
        } else if (email && !this.userSubject.value) {
          this.loadUser(email);
        }
      }
    });
  }

  public set currentUser(user: User) {
    this.userSubject.next(user);
  }

  public get currentUser(): User | null {
    return this.userSubject.value;
  }

  protected get emailUser(): string {
    return localStorage.getItem(this.storageEmailKey) || '';
  }

  public get storedGoogleTokenKey(): string {
    return localStorage.getItem(this.storageGoogleTokenKey) || '';
  }

  public clear() {
    setTimeout(() => {
      this.userSubject.next(null);
      localStorage.clear();
    }, 0);
  }

  public logout(): void {
    this.clear();
    window.location.href = '/login';
  }

  public async ensureLoaded(): Promise<void> {
    if (this.currentUser) return;

    const email = this.emailUser;
    if (!email) {
      this.userSubject.next(null);
      return;
    }

    await this.loadUser(email);
  }

  public async setUser(email: string): Promise<void> {
    localStorage.setItem(this.storageEmailKey, email);
    await this.loadUser(email);
  }

  private async loadUser(email: string): Promise<void> {
    try {
      const user = await this.getUserByEmail(email);
      this.userSubject.next(user);
    } catch {
      this.userSubject.next(null);
    }
  }

  public async getUserByEmail(email: string): Promise<User | null> {
    try {
      const response = await firstValueFrom(
        this.http
          .get<CustomHttpInterface<User>>(
            `${this.API_URL}/users/get-by?email=${email}`,
            { headers: { 'Content-Type': 'application/json' } }
          )
          .pipe(
            retry(3),
            catchError(() => of({ data: null }))
          )
      );
      return response.data;
    } catch {
      return null;
    }
  }

  public getAll(params: {
    limit?: number;
    page?: number;
    profile?: number;
  }): Observable<CustomHttpInterfacePaginate<User[]>> {
    let httpParams = new HttpParams();

    if (params.limit)
      httpParams = httpParams.set('limit', params.limit.toString());
    if (params.page)
      httpParams = httpParams.set('page', params.page.toString());
    if (params.profile)
      httpParams = httpParams.set('profile', params.profile.toString());

    return this.http.get<CustomHttpInterfacePaginate<User[]>>(
      `${this.API_URL}/users/get-list`,
      { params: httpParams }
    );
  }

  public getListUsersGestor(params: {
    limit?: number;
    page?: number;
    profile?: number;
  }): Observable<CustomHttpInterfacePaginate<UsersList[]>> {
    let httpParams = new HttpParams();

    if (params.limit)
      httpParams = httpParams.set('limit', params.limit.toString());
    if (params.page)
      httpParams = httpParams.set('page', params.page.toString());
    if (params.profile)
      httpParams = httpParams.set('profile', params.profile.toString());

    return this.http.get<CustomHttpInterfacePaginate<UsersList[]>>(
      `${this.API_URL}/users/get-users-gestor`,
      { params: httpParams }
    );
  }
  public getAllByProfile(params: {
    profile?: number;
  }): Observable<CustomHttpInterface<User[]>> {
    let httpParams = new HttpParams();
    if (params.profile) {
      httpParams = httpParams.set('profile', params.profile.toString());
    }
    return this.http.get<CustomHttpInterface<User[]>>(
      `${this.API_URL}/users/get-list`,
      { params: httpParams }
    );
  }

  public createUser(data: {
    run?: string;
    email: string;
    fullname: string;
    telefono: string;
    perfiles_id: number;
  }): Observable<CustomHttpInterface<User>> {
    return this.http.post<CustomHttpInterface<User>>(
      `${this.API_URL}/users/registro`,
      data
    );
  }
  public updateUser(data: {
    id: number;
    run?: string;
    email: string;
    fullname: string;
    telefono: string;
  }): Observable<CustomHttpInterface<{}>> {
    return this.http.put<CustomHttpInterface<{}>>(
      `${this.API_URL}/users/edit`,
      data
    );
  }
  public changeStatusUser(data: {
    id: number;
    run?: string;
  }): Observable<CustomHttpInterface<{}>> {
    return this.http.patch<CustomHttpInterface<{}>>(
      `${this.API_URL}/users/change-status`,
      data
    );
  }
}
