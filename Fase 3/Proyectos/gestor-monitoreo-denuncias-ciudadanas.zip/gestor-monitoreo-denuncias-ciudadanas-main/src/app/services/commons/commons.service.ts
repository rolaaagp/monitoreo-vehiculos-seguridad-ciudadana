import { HttpClient, HttpParams } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { map, Observable, of, tap } from 'rxjs';
import { CustomHttpInterface, Profile } from '@interfaces/index';
import { environment } from '@environments/environment';
import { PROFILES } from '@shared/constants/profiles.constants';

@Injectable({
  providedIn: 'root',
})
export class CommonsService {
  private readonly http = inject(HttpClient);
  private readonly API_URL = `${environment.API_DOMAINS.BASE}/${environment.API_DOMAINS.COMMONS_API}`;

  public publicHttp = inject(HttpClient);
  private cache = new Map<string, any>();

  getOptions<T = any>(params: {
    type:
      | 'estados'
      | 'requerimientos'
      | 'familias'
      | 'tipos_prioridad'
      | 'perfiles'
      | 'tipos_derivacion';
  }): Observable<CustomHttpInterface<T>> {
    const cacheKey = params.type;

    if (this.cache.has(cacheKey)) {
      return of(this.cache.get(cacheKey));
    }

    let httpParams = new HttpParams().set('t', params.type);

    return this.http
      .get<CustomHttpInterface<T>>(
        `${this.API_URL}/options/get-configuration-types`,
        { params: httpParams }
      )
      .pipe(
        map((response) => {
          if (params.type === 'perfiles') {
            response = {
              ...response,
              data: (response.data as Profile[]).filter(
                (profile: Profile) =>
                  ![PROFILES.ADMIN, PROFILES.CIUDADANO].includes(profile.id)
              ) as T,
            };
          }
          this.cache.set(cacheKey, response);
          return response;
        })
      );
  }

  getSignedUrl(params: {
    key: string;
    responseContentDisposition?: string;
  }): Observable<CustomHttpInterface<{ url: string }>> {
    let httpParams = new HttpParams();
    httpParams = httpParams.set('key', params.key);

    if (params.responseContentDisposition) {
      httpParams = httpParams.set(
        'responseContentDisposition',
        params.responseContentDisposition
      );
    }
    return this.http.get<CustomHttpInterface<{ url: string }>>(
      `${this.API_URL}/commons/get-signed-urls`,
      { params: httpParams }
    );
  }
  uploadFile(body: {
    key: string;
    fileName: string;
    base64Data: string;
    contentType: string;
  }): Observable<CustomHttpInterface<{}>> {
    return this.http.post<CustomHttpInterface<{}>>(
      `${this.API_URL}/commons/upload-file`,
      body
    );
  }
}
