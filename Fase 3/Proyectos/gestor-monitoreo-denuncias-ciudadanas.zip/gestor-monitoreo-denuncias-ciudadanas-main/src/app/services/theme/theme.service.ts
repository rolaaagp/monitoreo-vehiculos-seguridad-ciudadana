import { Injectable, signal } from '@angular/core';

type ThemeMode = 'light' | 'dark';

@Injectable({ providedIn: 'root' })
export class ThemeService {
  private readonly storageKey = 'theme';
  private readonly themeSignal = signal<ThemeMode>('light');

  theme() {
    return this.themeSignal();
  }

  init() {
    try {
      const saved = localStorage.getItem(this.storageKey) as ThemeMode | null;
      let mode: ThemeMode;
      if (saved === 'dark' || saved === 'light') {
        mode = saved;
      } else {
        const prefersDark = window.matchMedia?.('(prefers-color-scheme: dark)').matches;
        mode = prefersDark ? 'dark' : 'light';
      }
      this.apply(mode);
    } catch {
      this.apply('light');
    }
  }

  toggleTheme() {
    const next: ThemeMode = this.themeSignal() === 'dark' ? 'light' : 'dark';
    this.apply(next);
    try { localStorage.setItem(this.storageKey, next); } catch {}
  }

  setTheme(mode: ThemeMode) {
    this.apply(mode);
    try { localStorage.setItem(this.storageKey, mode); } catch {}
  }

  private apply(mode: ThemeMode) {
    this.themeSignal.set(mode);
    const body = document.body;
    if (mode === 'dark') body.classList.add('dark');
    else body.classList.remove('dark');
  }
}