import { inject, Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';
import { ToastrService } from '@services/toastr/toastr.service';
import { User } from '../../interfaces';
import { NgxSpinnerService } from 'ngx-spinner';
import { UsersService } from '@services/users/users.service';

declare global {
  interface Window {
    google: any;
  }
}

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private toastService = inject(ToastrService);

  constructor(
    private _userService: UsersService,
    private readonly spinnerService: NgxSpinnerService,
  ) {}

  loadGoogleScript(): Promise<void> {
    if (typeof window === 'undefined') return Promise.resolve();
    return new Promise((resolve) => {
      if (window.google && window.google.accounts) {
        resolve();
        return;
      }

      const existingScript = document.querySelector(
        'script[src="https://accounts.google.com/gsi/client"]'
      );
      if (existingScript) {
        existingScript.addEventListener('load', () => resolve());
        return;
      }

      const script = document.createElement('script');
      script.src = 'https://accounts.google.com/gsi/client';
      script.async = true;
      script.defer = true;
      script.onload = () => resolve();
      document.head.appendChild(script);
    });
  }

  initGoogleLogin(callback: (response: any) => void): void {
    if (typeof window === 'undefined' || typeof document === 'undefined')
      return;

    const el = document.getElementById('googleBtn');

    window.google.accounts.id.initialize({
      client_id: environment.GOOGLE_CLIENT_ID,
      callback,
      cancel_on_tap_outside: false,
    });

    if (el && el.children.length === 0) {
      window.google.accounts.id.renderButton(el, {
        theme: 'outline',
        size: 'large',
        width: 240,
      });
    }
    window.google.accounts.id.prompt();
  }

  async handleGoogleCredentialResponse(response: any): Promise<void> {
    console.log('[Google] Respuesta recibida:', response);

    if (!response?.credential) return;

    const token = response.credential;
    let email: string | undefined;

    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      email = payload?.email;
      if (!email) throw new Error('Email no presente en token');
    } catch {
      this.toastService.showWarning('Token inválido recibido de Google.');
      return;
    }

    this.spinnerService.show();
    
    setTimeout(() => {
      localStorage.setItem('email', email);
      localStorage.setItem('token', token);
    }, 0);

    const user = await this._userService.getUserByEmail(email);

    if (!user) {
      this.toastService.showWarning(
        'Usuario no encontrado. Contacte con un administrador.'
      );
      this.spinnerService.hide();
      return;
    }

    // if (!user.active) {
    //   this.toastService.showWarning(
    //     'Usuario no activo. Contacte con un administrador.'
    //   );

    //   this.spinnerService.hide();
    //   return;
    // }

    this.storeTokenUser({ token, user: user });
  }

  storeTokenUser(data: { token: string; user: User }): void {
    this._userService.currentUser = data.user;
    this.loginRedirect();
  }

  loginRedirect(): void {
    setTimeout(() => {
      window.location.href = '/home';
    }, 0);
  }

  logout(): void {
    this.spinnerService.show();
    this._userService.clear();
    window.location.href = '/login';
    this.spinnerService.hide();
  }
}
