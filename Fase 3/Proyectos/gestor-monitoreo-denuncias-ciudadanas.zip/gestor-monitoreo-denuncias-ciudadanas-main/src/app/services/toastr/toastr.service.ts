import { Injectable, Renderer2, RendererFactory2 } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ToastrService {
  private renderer: Renderer2;
  private toastContainer!: HTMLElement;

  constructor(private rendererFactory: RendererFactory2) {
    this.renderer = this.rendererFactory.createRenderer(null, null);
    this.createToastContainer();
  }

  private createToastContainer() {
    this.toastContainer = document.createElement('div');
    this.toastContainer.setAttribute('id', 'toast-container');
    this.toastContainer.className = 'fixed top-5 right-5 z-50 flex flex-col gap-3';
    document.body.appendChild(this.toastContainer);
  }

  private createToast(
    message: string,
    type: 'success' | 'error' | 'warning' | 'info' = 'info',
    duration = 4000
  ) {
    const baseClasses = 'alert shadow-lg max-w-sm relative animate-fade-in';
    const typeClasses = {
      success: 'alert-success',
      error: 'alert-error',
      warning: 'alert-warning',
      info: 'alert-info'
    };

    const toast = this.renderer.createElement('div');
    toast.className = `${baseClasses} ${typeClasses[type]}`;
    toast.setAttribute('role', 'alert');
    toast.setAttribute('aria-live', 'assertive');

    toast.innerHTML = `
    <span class="font-medium pr-2">${message}</span>
    <button class="btn btn-sm btn-circle btn-ghost absolute right-2 top-2" aria-label="Cerrar">&times;</button>
  `;

    const closeBtn = toast.querySelector('button');
    if (closeBtn) {
      closeBtn.addEventListener('click', () => this.fadeOutAndRemove(toast));
    }

    let timeoutId = setTimeout(() => this.fadeOutAndRemove(toast), duration);

    toast.addEventListener('mouseenter', () => {
      clearTimeout(timeoutId);
    });

    toast.addEventListener('mouseleave', () => {
      this.fadeOutAndRemove(toast);
    });

    this.toastContainer.appendChild(toast);
  }

  private fadeOutAndRemove(toast: HTMLElement) {
    toast.classList.remove('animate-fade-in');
    toast.classList.add('animate-fade-out');

    setTimeout(() => {
      if (this.toastContainer.contains(toast)) {
        this.toastContainer.removeChild(toast);
      }
    }, 500);
  }

  showSuccess(message: string, duration?: number) {
    this.createToast(message, 'success', duration);
  }

  showError(message: string, duration?: number) {
    this.createToast(message, 'error', duration);
  }

  showWarning(message: string, duration?: number) {
    this.createToast(message, 'warning', duration);
  }

  showInfo(message: string, duration?: number) {
    this.createToast(message, 'info', duration);
  }
}