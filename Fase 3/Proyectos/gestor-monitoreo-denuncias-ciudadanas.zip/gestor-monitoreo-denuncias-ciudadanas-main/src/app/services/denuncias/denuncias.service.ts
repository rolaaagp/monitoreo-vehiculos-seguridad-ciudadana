import { HttpClient, HttpParams } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import {
  CustomHttpInterface,
  CustomHttpInterfacePaginate,
  DenunciaList,
  ICrearDerivacion,
  IDashboardResponse,
  IDenunciaFull,
  IEvidencia,
  IHistorialGestion,
  IRequerimiento,
  RequestCrearDenuncia,
  User,
} from '@interfaces/index';
import { environment } from '@environments/environment';

@Injectable({
  providedIn: 'root',
})
export class DenunciaService {
  private readonly http = inject(HttpClient);
  private readonly API_URL = `${environment.API_DOMAINS.BASE}/${environment.API_DOMAINS.DENUNCIAS_API}`;

  getAll(params: {
    limit?: number;
    page?: number;
  }): Observable<CustomHttpInterfacePaginate<DenunciaList[]>> {
    let httpParams = new HttpParams();

    if (params.limit)
      httpParams = httpParams.set('limit', params.limit.toString());
    if (params.page)
      httpParams = httpParams.set('page', params.page.toString());

    return this.http.get<CustomHttpInterfacePaginate<DenunciaList[]>>(
      `${this.API_URL}/denuncias/get-list`,
      { params: httpParams }
    );
  }

  getById(id: number): Observable<CustomHttpInterface<IDenunciaFull>> {
    return this.http.get<CustomHttpInterface<IDenunciaFull>>(
      `${this.API_URL}/denuncias/get?id=${id}`
    );
  }

  public cambiarRequerimiento(data: {
    id: number;
    requerimiento_id: number;
    user_id: number;
  }): Observable<CustomHttpInterface<IHistorialGestion>> {
    return this.http.patch<CustomHttpInterface<IHistorialGestion>>(
      `${this.API_URL}/denuncias/cambiar-requerimiento`,
      data
    );
  }
  public cambiarEstado(data: {
    id: number;
    estado_id: number;
    user_id: number;
  }): Observable<CustomHttpInterface<IHistorialGestion>> {
    return this.http.patch<CustomHttpInterface<IHistorialGestion>>(
      `${this.API_URL}/denuncias/cambiar-estado`,
      data
    );
  }
  public asignar(data: {
    id: number;
    user_id_asignado: number;
    user_id: number;
  }): Observable<CustomHttpInterface<IHistorialGestion>> {
    return this.http.patch<CustomHttpInterface<IHistorialGestion>>(
      `${this.API_URL}/denuncias/asignar`,
      data
    );
  }
  public cambiarFamilia(data: {
    id: number;
    familia_id: number;
    user_id: number;
  }): Observable<CustomHttpInterface<IHistorialGestion>> {
    return this.http.patch<CustomHttpInterface<IHistorialGestion>>(
      `${this.API_URL}/denuncias/cambiar-familia`,
      data
    );
  }

  public agregarRequerimientoAdic(data: {
    denuncia_id: number;
    nombre_requerimiento: string;
    tipo_prioridad_id: number;
    user_id: number;
  }): Observable<
    CustomHttpInterface<{
      historial: IHistorialGestion;
      requerimiento: IRequerimiento;
    }>
  > {
    return this.http.post<
      CustomHttpInterface<{
        historial: IHistorialGestion;
        requerimiento: IRequerimiento;
      }>
    >(`${this.API_URL}/denuncias/agregar-requerimiento-adicional`, data);
  }
  public subirEvidenciaDenuncia(data: {
    denuncia_id: number;
    evidencias: {
      filename: string;
      base64Data: string;
      contentType: string;
    }[];
  }): Observable<CustomHttpInterface<IEvidencia[]>> {
    return this.http.post<CustomHttpInterface<IEvidencia[]>>(
      `${this.API_URL}/denuncias/subir-evidencia-denuncia`,
      data
    );
  }
  public cambiarVisibilidadVecino(data: {
    id: number;
    visible: boolean;
    user_id: number;
  }): Observable<CustomHttpInterface<IHistorialGestion>> {
    return this.http.patch<CustomHttpInterface<IHistorialGestion>>(
      `${this.API_URL}/denuncias/cambiar-visibilidad-vecino`,
      data
    );
  }
  public derivar(data: {
    detalle: string;
    denuncia_id: number;
    estados_derivacion_id: number;
    tipo_derivacion_id: number;
    user_id: number;
  }): Observable<
    CustomHttpInterface<{
      historial: IHistorialGestion;
      derivacion: ICrearDerivacion;
    }>
  > {
    return this.http.post<
      CustomHttpInterface<{
        historial: IHistorialGestion;
        derivacion: ICrearDerivacion;
      }>
    >(`${this.API_URL}/denuncias/crear-derivacion`, data);
  }

  getDashboard(): Observable<
    CustomHttpInterface<{
      top3PorEstado: IDashboardResponse[];
      creadasHoy: number;
    }>
  > {
    return this.http.get<
      CustomHttpInterface<{
        top3PorEstado: IDashboardResponse[];
        creadasHoy: number;
      }>
    >(`${this.API_URL}/dashboard/get`);
  }
  public crearDenuncia(data: RequestCrearDenuncia): Observable<CustomHttpInterface<{ do: boolean }>> {
    return this.http.post<CustomHttpInterface<{ do: boolean }>>(
      `${this.API_URL}/denuncias/registro`,
      data
    );
  }
}
