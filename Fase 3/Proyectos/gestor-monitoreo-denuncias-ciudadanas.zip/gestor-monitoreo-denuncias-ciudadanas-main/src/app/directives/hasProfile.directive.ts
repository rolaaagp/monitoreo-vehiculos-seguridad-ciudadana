import {
  Directive,
  Input,
  TemplateRef,
  ViewContainerRef,
  inject,
} from '@angular/core';
import { UsersService } from '@services/users/users.service';
import { User } from '@interfaces/user.interface';

@Directive({
  selector: '[appHasProfile]',
})
export class HasProfileDirective {
  private perfilesPermitidos: number[] = [];
  private user: User | null = null;

  private _userService = inject(UsersService);
  private templateRef = inject(TemplateRef<any>);
  private viewContainer = inject(ViewContainerRef);

  @Input() set appHasProfile(perfiles: number[]) {
    this.perfilesPermitidos = perfiles || [];
    this.verificarAcceso();
  }

  constructor() {
    this._userService.currentUser$.subscribe((u) => {
      this.user = u;
      this.verificarAcceso();
    });
  }

  private verificarAcceso() {
    this.viewContainer.clear();

    if (!this.user || !this.user.perfil?.id) return;

    const tieneAcceso = this.perfilesPermitidos.includes(
      this.user.perfil.id
    );

    if (tieneAcceso) this.viewContainer.createEmbeddedView(this.templateRef);
  }
}
