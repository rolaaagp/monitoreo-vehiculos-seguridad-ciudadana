import { User } from './user.interface';

export interface DenunciaList {
  id: number;
  fecha: string;
  es_anonimo: boolean;
  tiene_derivacion: boolean;
  detalle: string;
  ubicacion: string;
  latitud?: string;
  longitud?: string;
  visible_para_vecinos: boolean;
  estado: {
    id: number;
    nombre: string;
  };
  user: {
    id: number;
    perfiles_id: number;
    run: string | null;
    fullname: string;
    telefono: string;
    email: string | null;
    password: string;
    activo: boolean;
    created_at: string;
    perfil: {
      id: number;
      nombre: string;
    };
  };
  requerimiento:
    | ({
        tipo_prioridad: {
          id: number;
          nombre: string;
        };
      } & {
        id: number;
        nombre: string;
        activo: boolean;
        sub_grupos_id: number;
        tipos_prioridad_id: number;
      })
    | null;
}

export interface IEstadoDenuncia {
  id: number;
  nombre: string;
  activo: boolean;
}

export interface IDerivacion {
  id: number;
  detalle: string | null;
  denuncias_id: number;
  estados_derivacion_id: number;
  fecha_derivacion: string;
}

export interface ICuadrante {
  id: number;
  nombre: string;
  codigo: string;
}

export interface IEvidencia {
  id: number;
  key_s3: string;
  denuncias_id: number;
  tipo: string | null;
  descripcion: string | null;
  fecha_subida: string;
}

export interface IFamilia {
  id: number;
  nombre: string;
}

export interface IHistorialGestion {
  id: number;
  denuncias_id: number;
  users_id: number;
  accion: string;
  detalle: string | null;
  fecha: string;
}

export interface IMovil {
  id: number;
  patente: string | null;
  modelo: string | null;
  activo: boolean;
}

export interface IMovilConductor {
  id: number;
  moviles_id: number;
  users_id: number;
  fecha_asignacion: string;
  user: User;
}

export interface IMovilAsociado {
  id: number;
  denuncias_id: number;
  moviles_conductores_id: number;
  moviles_id: number;
  fecha_asignacion: string;
  movil: IMovil;
  movil_conductor: IMovilConductor;
}

export interface IOperador {
  id: number;
  denuncias_id: number;
  users_id: number;
  user: User;
}

export interface ITipoPrioridad {
  id: number;
  nombre: string;
}

export interface IRequerimiento {
  id: number;
  nombre: string;
  tipo_prioridad_id: number | null;
  activo: boolean;
  tipo_prioridad: ITipoPrioridad | null;
}

export interface IDenunciaFull {
  id: number;
  folio: number | null;
  users_id: number;
  tipos_denuncias_id: number | null;
  requerimiento_id: number | null;
  estado_id: number | null;
  cuadrantes_id: number | null;
  users_id_valida: number | null;
  users_id_asignado: number | null;
  detalle: string;
  observaciones: string | null;
  fecha: string;
  fecha_creacion: string;
  fecha_validacion: string | null;
  fecha_asignacion: string | null;
  fecha_conclusion: string | null;
  fecha_limite_visibilidad: string | null;
  latitud: number;
  longitud: number;
  ubicacion: string | null;
  es_anonimo: boolean;
  es_alta_connotacion: boolean;
  es_vif: boolean;
  entidad_derivada: string | null;

  visible_para_vecinos: boolean;

  estado: IEstadoDenuncia | null;
  user: User;
  user_asignado: User | null;
  derivaciones: IDerivacion[];
  cuadrante: ICuadrante | null;
  evidencia?: IEvidencia[];
  familia: IFamilia | null;
  historial_gestiones?: IHistorialGestion[];
  moviles_assoc: IMovilAsociado[];
  operadores: IOperador[];
  requerimiento: IRequerimiento | null;
  requerimiento_adicional_denuncia: IRequerimiento[] | null;
}

export interface ITipoDerivacion {
  id: number;
  nombre: string;
  activo: boolean;
}

export interface IDerivacion {
  detalle: string | null;
  id: number;
  denuncias_id: number;
  fecha_derivacion: string;
  estados_derivacion_id: number;
  estado_derivacion: IEstadoDerivacion | null;
  tipo_derivacion_id: number;
  tipo_derivacion: ITipoDerivacion | null;
}

export interface IEstadoDerivacion {
  id: number;
  nombre: string | null;
}

export type ICrearDerivacion = IDerivacion;

export interface IDashboardResponse {
  estado_id: number;
  estado_nombre: string;
  total_denuncias: number;
  top3_requerimientos: { nombre: string; cantidad: number }[];
}

export interface RequestCrearDenuncia {
  ubicacion: string;
  detalle: string;
  fecha_completa: string;
  user_id: number;
  tipo_denuncia?: number;
  requerimiento_id?: number;
  latitud: number;
  longitud: number;
  evidencias?: {
    filename: string;
    base64Data: string;
    contentType: string;
  }[];
}
