export interface User {
  id: number;
  run: string | null;
  fullname: string;
  telefono: string;
  email: string | null;
  activo: boolean;
  created_at: string;
  perfil: Profile;
  perfiles_id?: number;
}
export type UsersList = User & {
  canEdit?: boolean;
  canChangeStatus?: boolean;
};

export interface Profile {
  id: number;
  nombre: string | null;
}
