export * from './http.interface';
export * from './user.interface';
export * from './denuncia.interface';