import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { UsersService } from '@services/users/users.service';

export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const _userService = inject(UsersService)
    const token = _userService.storedGoogleTokenKey;

  if (token) {
    const clonedRequest = req.clone({
      setHeaders: {
        Authorization: `Bearer ${token}`,
      },
    });
    return next(clonedRequest);
  }

  return next(req);
};
