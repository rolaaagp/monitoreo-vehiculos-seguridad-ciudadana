import { Component, ElementRef, inject, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet } from '@angular/router';
import { NgxSpinnerModule } from 'ngx-spinner';
import { UpdateWorkerComponent } from './shared/update-worker/update-worker.component';
import { WebServiceWorker } from './services/worker';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  standalone: true,
  imports: [
    CommonModule,
    RouterOutlet,
    NgxSpinnerModule,
    UpdateWorkerComponent,
  ],
})
export class AppComponent {
  private webServiceWorker = inject(WebServiceWorker);
  @ViewChild('sidebar') sidebar!: ElementRef;
  title = 'educacion-app';
  sidebarCollapsed = true;
  isNewAppVersionAvailable: boolean = false;
  newAppUpdateAvailableSubscription: any;

  onSidebarToggle(state: boolean) {
    this.sidebarCollapsed = state;
  }

  ngOnInit(): void {
    this.checkIfAppUpdated();
  }

  checkIfAppUpdated() {
    this.newAppUpdateAvailableSubscription =
      this.webServiceWorker.$isAnyNewUpdateAvailable.subscribe(
        (versionAvailableFlag: boolean) => {
          console.log(
            'isNewAppVersionAvailable: ',
            this.isNewAppVersionAvailable
          );
          this.isNewAppVersionAvailable = versionAvailableFlag;
        }
      );
  }

  refreshApp() {
    this.webServiceWorker.swUpdate
      .activateUpdate()
      .then(() => document.location.reload());
  }

  ngOnDestroy() {
    if (this.newAppUpdateAvailableSubscription) {
      this.newAppUpdateAvailableSubscription.unsubscribe();
    }
  }
}
