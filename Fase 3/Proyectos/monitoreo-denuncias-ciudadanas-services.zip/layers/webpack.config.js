const nodeExternals = require('webpack-node-externals')
const CopyPlugin = require('copy-webpack-plugin')
const { execSync } = require('child_process')
const path = require('path')
const fs = require('fs')

module.exports = {
  externals: [nodeExternals()],
  plugins: [
    {
      apply: (compiler) => {
        compiler.hooks.beforeRun.tap('PrismaCleanup', () => {
          execSync('npx prisma generate', { stdio: 'inherit' })
          const prismaDir = path.resolve(__dirname, 'node_modules/.prisma/client')
          fs.readdirSync(prismaDir)
            .filter(f => f.startsWith('libquery_engine-') && !f.includes('rhel-openssl-3.0.x'))
            .forEach(f => fs.rmSync(path.join(prismaDir, f)))
        })
      }
    },
    new CopyPlugin({
      patterns: [
        { from: './node_modules/.prisma/client/schema.prisma', to: './' },
      ],
    }),
  ],
}
