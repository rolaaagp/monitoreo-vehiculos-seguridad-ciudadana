import {
  LambdaResponseUtils,
  getObjectSignedUrl,
  Callback,
  Context,
  Handler,
} from "utils";
import { createPrismaClient } from "database";

async function processHandler(_event: any, callback: Callback) {
  let prisma: ReturnType<typeof createPrismaClient> | null = null;

  try {
    const { BDName, BDUser, BDPassword, BDHost, REGION, BUCKET_NAME } =
      process.env as Record<string, string>;
    prisma = createPrismaClient({ BDName, BDUser, BDPassword, BDHost });

    const query = _event.queryStringParameters || {};

    const key = query.key;

    const responseContentDisposition =
      query.responseContentDisposition || undefined;

    const url = await getObjectSignedUrl({
      bucket: BUCKET_NAME,
      region: REGION,
      expiresInSeconds: 3600,
      key: key,
      responseContentDisposition,
    });

    LambdaResponseUtils.success({
      data: { url },
      callback,
      message: "Realizado correctamente",
      statusCode: "OK",
    });
  } catch (err) {
    console.error("Error general ->", err);
    LambdaResponseUtils.error({
      errorData: err,
      callback,
      message: "Ha ocurrido un error",
      statusCode: "INTERNAL_SERVER_ERROR",
    });
  } finally {
    if (prisma) await prisma.$disconnect();
  }
}

export const handler: Handler = async (
  _event: any,
  context: Context,
  callback: Callback
) => {
  context.callbackWaitsForEmptyEventLoop = false;
  await processHandler(_event, callback);
};
