import { Callback } from "aws-lambda";
import { LambdaResponseUtils } from "utils";
import { createPrismaClient } from "database";

type StrategyParams = {
  prisma: ReturnType<typeof createPrismaClient>;
  id?: number;
  dimension_id?: number;
};

type StrategyMap = {
  [key: string]: (params: StrategyParams) => Promise<any>;
};

const strategies: StrategyMap = {
  estados: ({ prisma }) =>
    prisma.estados_denuncia.findMany({
      orderBy: { nombre: "asc" },
      where: { activo: true },
    }),
  requerimientos: ({ prisma }) =>
    prisma.requerimientos.findMany({
      orderBy: { nombre: "asc" },
      where: { activo: true },
      include: {
        tipo_prioridad: true,
      },
    }),
  familias: ({ prisma }) =>
    prisma.familias.findMany({ orderBy: { nombre: "asc" } }),
  tipos_prioridad: ({ prisma }) =>
    prisma.tipos_prioridad.findMany({ orderBy: { nombre: "asc" } }),
  perfiles: ({ prisma }) =>
    prisma.perfiles.findMany({ orderBy: { nombre: "asc" } }),
  tipos_derivacion: ({ prisma }) =>
    prisma.tipos_derivaciones.findMany({
      orderBy: { nombre: "asc" },
      where: { activo: true },
    }),
};

type Params = {
  t:
    | "estados"
    | "requerimientos"
    | "familias"
    | "tipos_prioridad"
    | "perfiles"
    | "tipos_derivacion";
  id?: number;
};

export async function processHandler(event: any, callback: Callback) {
  let prisma: ReturnType<typeof createPrismaClient> | null = null;

  try {
    const { BDName, BDUser, BDPassword, BDHost } = process.env as Record<
      string,
      string
    >;

    prisma = createPrismaClient({ BDName, BDUser, BDPassword, BDHost });

    const params: Params = event?.queryStringParameters;

    const type = params?.t;

    const id = params?.id ? Number(params.id) : undefined;

    if (!type || !(type in strategies)) {
      LambdaResponseUtils.error({
        errorData: { error: `Tipo inválido '${type}'` },
        callback,
        message: 'Parámetro "t" requerido o inválido',
        statusCode: "BAD_REQUEST",
      });
      return;
    }

    const result = await strategies[type]({
      prisma,
      id,
    });

    LambdaResponseUtils.success({
      data: result,
      callback,
      message: "Realizado correctamente",
      statusCode: "OK",
    });
  } catch (err) {
    console.error("Error general -> ", err);
    LambdaResponseUtils.error({
      errorData: err,
      callback,
      message: "Ha ocurrido un error",
      statusCode: "INTERNAL_SERVER_ERROR",
    });
  } finally {
    if (prisma) await prisma.$disconnect();
  }
}

export const handler = async (
  _event: any,
  context: any,
  callback: Callback
) => {
  context.callbackWaitsForEmptyEventLoop = false;
  return await processHandler(_event, callback);
};
