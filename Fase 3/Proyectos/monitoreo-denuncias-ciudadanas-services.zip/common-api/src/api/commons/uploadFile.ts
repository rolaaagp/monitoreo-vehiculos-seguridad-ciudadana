import {
  LambdaResponseUtils,
  Callback,
  Context,
  Handler,
  uploadFile,
} from "utils";

interface Body {
  key: string;
  fileName: string;
  base64Data: string;
  contentType: string;
}

async function processHandler(_event: any, callback: Callback) {
  try {
    const { REGION, BUCKET_NAME } = process.env as Record<string, string>;
    const body: Body = JSON.parse(_event.body);

    const base64Data = body.base64Data.replace(/^data:.*;base64,/, "");

    await uploadFile({
      bucket: BUCKET_NAME,
      key: body.key,
      base64Data,
      contentType: body.contentType,
      region: REGION,
    });

    LambdaResponseUtils.success({
      data: {},
      callback,
      message: "Realizado correctamente",
      statusCode: "OK",
    });
  } catch (err) {
    console.error("Error general ->", err);
    LambdaResponseUtils.error({
      errorData: err,
      callback,
      message: "Ha ocurrido un error",
      statusCode: "INTERNAL_SERVER_ERROR",
    });
  }
}

export const handler: Handler = async (
  _event: any,
  context: Context,
  callback: Callback
) => {
  context.callbackWaitsForEmptyEventLoop = false;
  await processHandler(_event, callback);
};
