import {
  LambdaResponseUtils,
  Callback,
  decryptPassword,
  APIGatewayProxyEvent,
  Handler,
  Context,
} from "utils";
import { createPrismaClient } from "database";

type TPrisma = ReturnType<typeof createPrismaClient>;

interface Body {
  run?: string;
  email?: string;
  password: string;
}

export async function processHandler(
  event: APIGatewayProxyEvent,
  callback: Callback
) {
  let prisma: TPrisma | null = null;

  try {
    const { BDName, BDUser, BDPassword, BDHost, ENCRYPTION_KEY } =
      process.env as Record<string, string>;

    prisma = createPrismaClient({ BDName, BDUser, BDPassword, BDHost });

    const body: Body = JSON.parse(event?.body as string);

    const user = await prisma.users.findFirst({
      where: {
        OR: [{ email: body.email }, { run: body.run }],
      },
    });

    if (!user) {
      return LambdaResponseUtils.success({
        data: null,
        callback,
        message: "Usuario no encontrado",
        statusCode: "OK",
      });
    }

    // Desencriptar y comparar
    const decrypted = decryptPassword(user.password, ENCRYPTION_KEY);
    const valid = decrypted === body.password;

    if (!valid) {
      return LambdaResponseUtils.success({
        data: null,
        callback,
        message: "Contraseña incorrecta",
        statusCode: "OK",
      });
    }

    const { password, ...userWithoutPwd } = user;

    LambdaResponseUtils.success({
      data: userWithoutPwd,
      callback,
      message: "Login correcto",
      statusCode: "OK",
    });
  } catch (err) {
    console.error("Error general -> ", err);
    LambdaResponseUtils.error({
      errorData: err,
      callback,
      message: "Ha ocurrido un error",
      statusCode: "INTERNAL_SERVER_ERROR",
    });
  } finally {
    if (prisma) await prisma.$disconnect();
  }
}

export const handler: Handler = async (
  _event: any,
  context: Context,
  callback: Callback
) => {
  context.callbackWaitsForEmptyEventLoop = false;
  return await processHandler(_event, callback);
};
