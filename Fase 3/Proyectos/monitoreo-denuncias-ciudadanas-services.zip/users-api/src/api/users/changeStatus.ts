import { LambdaResponseUtils, Callback, Context, Handler } from "utils";
import { createPrismaClient } from "database";

type TPrisma = ReturnType<typeof createPrismaClient>;

interface UserBody {
  id: number;
  activo: boolean;
}

export async function processHandler(event: any, callback: Callback) {
  let prisma: TPrisma | null = null;

  try {
    const { BDName, BDUser, BDPassword, BDHost } = process.env as Record<
      string,
      string
    >;

    const body: UserBody = JSON.parse(event?.body as string);

    prisma = createPrismaClient({ BDName, BDUser, BDPassword, BDHost });

    await prisma.$transaction(async (tx) => {
      const updated = await tx.users.update({
        where: { id: body.id },
        data: {
          activo: body.activo,
        },
      });
      return updated;
    });

    LambdaResponseUtils.success({
      data: {},
      callback,
      message: "Realizado correctamente",
      statusCode: "OK",
    });
  } catch (err) {
    console.error("Error general -> ", err);
    LambdaResponseUtils.error({
      errorData: err,
      callback,
      message: "Ha ocurrido un error",
      statusCode: "INTERNAL_SERVER_ERROR",
    });
  } finally {
    if (prisma) await prisma.$disconnect();
  }
}

export const handler: Handler = async (
  _event: any,
  context: Context,
  callback: Callback
) => {
  context.callbackWaitsForEmptyEventLoop = false;
  return await processHandler(_event, callback);
};
