import { LambdaResponseUtils, Callback, Context, Handler } from "utils";
import { createPrismaClient, paginate, PrismaTypes } from "database";

type TPrisma = ReturnType<typeof createPrismaClient>;

export async function processHandler(event: any, callback: Callback) {
  let prisma: TPrisma | null = null;
  try {
    const { BDName, BDUser, BDPassword, BDHost } = process.env as Record<
      string,
      string
    >;
    prisma = createPrismaClient({ BDName, BDUser, BDPassword, BDHost });

    const params: {
      page?: string;
      limit?: string;
      profile?: string;
    } = event.queryStringParameters || {};

    console.log("params", params);

    let results;

    let where: PrismaTypes.Prisma.usersWhereInput | undefined = undefined;

    if (params.profile) {
      where = {};
      where.perfiles_id = Number(params.profile);
    } else {
      where = {};
      where.perfiles_id = {
        notIn: [1,2], // Exclude ADMIN, VECINO
      }
    }

    if (!params.limit || !params.page) {
      results = await prisma.users.findMany({
        where,
        omit: {
          password: true,
        },
      });
    } else {
      const page = Number(params.page);
      const limit = Number(params.limit);

      const data = await paginate({
        event,
        params: {
          page: page,
          limit: limit,
        },
        findManyCallback: (skip: number, take: number) =>
          prisma!.users.findMany({
            skip,
            take,
            where,
            include: {
              perfil: true,
            },
            omit: {
              password: true,
            },
          }),
        countCallback: () => prisma!.users.count({ where }),
      });

      results = data;
    }

    LambdaResponseUtils.success({
      data: results,
      callback,
      message: "Realizado correctamente",
      statusCode: "OK",
    });
  } catch (err) {
    console.error("Error general -> ", err);
    LambdaResponseUtils.error({
      errorData: err,
      callback,
      message: "Ha ocurrido un error",
      statusCode: "INTERNAL_SERVER_ERROR",
    });
  } finally {
    if (prisma) await prisma.$disconnect();
  }
}

export const handler: Handler = async (
  _event: any,
  context: Context,
  callback: Callback
) => {
  context.callbackWaitsForEmptyEventLoop = false;
  return await processHandler(_event, callback);
};
