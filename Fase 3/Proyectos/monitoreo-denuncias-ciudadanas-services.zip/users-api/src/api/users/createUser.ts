import {
  LambdaResponseUtils,
  Callback,
  Context,
  Handler,
  encryptPassword,
} from "utils";
import { createPrismaClient } from "database";

type TPrisma = ReturnType<typeof createPrismaClient>;

interface UserBody {
  run?: string;
  email: string;
  fullname: string;
  telefono: string;
  password?: string;
  perfiles_id: number;
}

export async function processHandler(event: any, callback: Callback) {
  let prisma: TPrisma | null = null;

  try {
    const { BDName, BDUser, BDPassword, BDHost, ENCRYPTION_KEY } =
      process.env as Record<string, string>;

    const body: UserBody = JSON.parse(event?.body as string);

    prisma = createPrismaClient({ BDName, BDUser, BDPassword, BDHost });

    const hashed = body.password
      ? encryptPassword(body.password, ENCRYPTION_KEY)
      : undefined;

    let userExists = 0;
    let createdUser = null;

    if (body?.run && body?.run.length > 0) {
      const exists = await prisma.users.findFirst({
        where: { run: { contains: body.run } },
      });
      if (exists) {
        userExists = 1;
      }
    }

    if (body?.email && body?.email.length > 0) {
      const exists = await prisma.users.findFirst({
        where: { email: { contains: body.email } },
      });
      if (exists) {
        userExists = 2;
      }
    }

    if (!userExists) {
      const user = await prisma.$transaction(async (tx) => {
        const newUser = await tx.users.create({
          data: {
            perfiles_id: Number(body.perfiles_id),
            run: body.run,
            fullname: body.fullname,
            telefono: body.telefono,
            password: hashed,
            email: body.email,
            activo: true,
          },
          include: {
            perfil: true,
          },
        });
        return newUser;
      });

      const { password, ...userWithoutPwd } = user;
      createdUser = userWithoutPwd;
    }

    LambdaResponseUtils.success({
      data: {
        user: createdUser,
        user_exists: userExists,
      },
      callback,
      message:
        userExists === 1
          ? "El RUN ingresado ya se encuentra registrado"
          : userExists === 2
          ? "El correo electrónico ingresado ya se encuentra registrado"
          : "Usuario creado correctamente",
      statusCode: "OK",
    });
  } catch (err) {
    console.error("Error general -> ", err);
    LambdaResponseUtils.error({
      errorData: err,
      callback,
      message: "Ha ocurrido un error",
      statusCode: "INTERNAL_SERVER_ERROR",
    });
  } finally {
    if (prisma) await prisma.$disconnect();
  }
}

export const handler: Handler = async (
  _event: any,
  context: Context,
  callback: Callback
) => {
  context.callbackWaitsForEmptyEventLoop = false;
  return await processHandler(_event, callback);
};
