import { LambdaResponseUtils, Callback, Context, Handler } from "utils";
import { createPrismaClient } from "database";

type TPrisma = ReturnType<typeof createPrismaClient>;

export async function processHandler(event: any, callback: Callback) {
  let prisma: TPrisma | null = null;
  try {
    const { BDName, BDUser, BDPassword, BDHost } = process.env as Record<
      string,
      string
    >;
    prisma = createPrismaClient({ BDName, BDUser, BDPassword, BDHost });

    const params: { id?: number; run?: string, email?: string } =
      event.queryStringParameters || {};

    const where: any = {};

    if (params.id) where.id = Number(params.id);
    if (params.run) where.run = { contains: params.run };
    if (params.email) where.email = { contains: params.email };

    const user = await prisma.users.findFirst({
      where,
      select: {
        id: true,
        fullname: true,
        run: true,
        telefono: true,
        email: true,
        activo: true,
        perfil: {
          select: {
            id: true,
            nombre: true,
          },
        },
      },
    });

    LambdaResponseUtils.success({
      data: user,
      callback,
      message: "Realizado correctamente",
      statusCode: "OK",
    });
  } catch (err) {
    console.error("Error general -> ", err);
    LambdaResponseUtils.error({
      errorData: err,
      callback,
      message: "Ha ocurrido un error",
      statusCode: "INTERNAL_SERVER_ERROR",
    });
  } finally {
    if (prisma) await prisma.$disconnect();
  }
}

export const handler: Handler = async (
  _event: any,
  context: Context,
  callback: Callback
) => {
  context.callbackWaitsForEmptyEventLoop = false;
  return await processHandler(_event, callback);
};
