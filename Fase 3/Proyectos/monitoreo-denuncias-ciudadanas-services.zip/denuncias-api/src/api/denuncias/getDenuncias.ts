import { LambdaResponseUtils, Callback, Context, Handler } from "utils";
import { createPrismaClient, paginate, PrismaTypes } from "database";

type TPrisma = ReturnType<typeof createPrismaClient>;

export async function processHandler(event: any, callback: Callback) {
  let prisma: TPrisma | null = null;
  try {
    const { BDName, BDUser, BDPassword, BDHost } = process.env as Record<
      string,
      string
    >;
    prisma = createPrismaClient({ BDName, BDUser, BDPassword, BDHost });

    const params: {
      page?: string;
      limit?: string;
      visible_para_vecinos?: "si" | "no";
    } = event.queryStringParameters || {};

    console.log("params", params);

    let visible_para_vecinos: boolean | undefined = undefined;

    if (params.visible_para_vecinos === "si") visible_para_vecinos = true;
    if (params.visible_para_vecinos === "no") visible_para_vecinos = false;

    let results;

    const where: PrismaTypes.Prisma.denunciasWhereInput = {};
    if (visible_para_vecinos !== undefined) {
      where.visible_para_vecinos = visible_para_vecinos;
    }

    const include: PrismaTypes.Prisma.denunciasInclude = {
      estado: true,
      user: true,
      derivaciones: {
        include: {
          estado_derivacion: true,
          tipo_derivacion: true,
        },
      },
      requerimiento: {
        include: {
          tipo_prioridad: true,
        },
      },
    };
    if (!params.limit || !params.page) {
      results = await prisma.denuncias.findMany({ where, include });
    } else {
      const page = Number(params.page);
      const limit = Number(params.limit);

      const data = await paginate({
        event,
        params: {
          page: page,
          limit: limit,
        },
        findManyCallback: (skip: number, take: number) =>
          prisma!.denuncias.findMany({
            skip,
            take,
            where,
            include,
          }),
        countCallback: () => prisma!.denuncias.count({ where }),
      });

      results = {
        ...data,
        items: data.items.map((item) => ({
          id: item.id,
          fecha: item.fecha,
          es_anonimo: item.es_anonimo,
          estado: item.estado,
          user: item.es_anonimo ? null : item.user,
          requerimiento: item.requerimiento,
          tiene_derivacion: item.derivaciones && item.derivaciones?.length > 0,
          visible_para_vecinos: item.visible_para_vecinos,
          latitud: item.latitud,
          longitud: item.longitud,
          direccion: item.ubicacion,
          derivaciones: item.derivaciones,
        })),
      };
    }

    LambdaResponseUtils.success({
      data: results,
      callback,
      message: "Realizado correctamente",
      statusCode: "OK",
    });
  } catch (err) {
    console.error("Error general -> ", err);
    LambdaResponseUtils.error({
      errorData: err,
      callback,
      message: "Ha ocurrido un error",
      statusCode: "INTERNAL_SERVER_ERROR",
    });
  } finally {
    if (prisma) await prisma.$disconnect();
  }
}

export const handler: Handler = async (
  _event: any,
  context: Context,
  callback: Callback
) => {
  context.callbackWaitsForEmptyEventLoop = false;
  return await processHandler(_event, callback);
};
