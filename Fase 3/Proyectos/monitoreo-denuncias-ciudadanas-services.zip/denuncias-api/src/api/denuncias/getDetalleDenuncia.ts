import { LambdaResponseUtils, Callback, Context, Handler } from "utils";
import { createPrismaClient } from "database";

type TPrisma = ReturnType<typeof createPrismaClient>;

export async function processHandler(event: any, callback: Callback) {
  let prisma: TPrisma | null = null;
  try {
    const { BDName, BDUser, BDPassword, BDHost } = process.env as Record<
      string,
      string
    >;
    prisma = createPrismaClient({ BDName, BDUser, BDPassword, BDHost });

    const params: {
      id?: string;
    } = event.queryStringParameters || {};

    console.log("params", params);

    if (!params.id) {
      return LambdaResponseUtils.error({
        errorData: { error: "Parámetros inválidos." },
        callback,
        message: "Parámetros inválidos.",
        statusCode: "BAD_REQUEST",
      });
    }

    const denuncia = await prisma.denuncias.findUnique({
      where: {
        id: Number(params.id),
      },
      include: {
        estado: true,
        user: {
          omit: {
            password: true,
          },
          include: {
            perfil: true,
          },
        },
        derivaciones: {
          include: {
            estado_derivacion: true,
            tipo_derivacion: true,
          }
        },
        cuadrante: true,
        evidencia: true,
        familia: true,
        historial_gestiones: true,
        user_asignado: {
          omit: {
            password: true,
          },
        },
        moviles_assoc: {
          include: {
            movil: true,
            movil_conductor: {
              include: {
                user: {
                  include: {
                    perfil: true,
                  },
                  omit: {
                    password: true,
                  },
                },
              },
            },
          },
        },
        operadores: {
          include: {
            user: {
              include: {
                perfil: true,
              },
              omit: {
                password: true,
              },
            },
          },
        },
        requerimiento: {
          include: {
            tipo_prioridad: true,
          },
        },
        requerimiento_adicional_denuncia: {
          include: {
            tipo_prioridad: true,
          },
        },
      },
    });

    LambdaResponseUtils.success({
      data: denuncia,
      callback,
      message: "Realizado correctamente",
      statusCode: "OK",
    });
  } catch (err) {
    console.error("Error general -> ", err);
    LambdaResponseUtils.error({
      errorData: err,
      callback,
      message: "Ha ocurrido un error",
      statusCode: "INTERNAL_SERVER_ERROR",
    });
  } finally {
    if (prisma) await prisma.$disconnect();
  }
}

export const handler: Handler = async (
  _event: any,
  context: Context,
  callback: Callback
) => {
  context.callbackWaitsForEmptyEventLoop = false;
  return await processHandler(_event, callback);
};
