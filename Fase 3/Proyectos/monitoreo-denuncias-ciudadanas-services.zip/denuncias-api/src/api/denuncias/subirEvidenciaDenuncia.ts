import {
  LambdaResponseUtils,
  Callback,
  Context,
  Handler,
  APIGatewayProxyEvent,
  uploadFile,
  lookup,
} from "utils";
import { createPrismaClient, PrismaTypes } from "database";

type TPrisma = ReturnType<typeof createPrismaClient>;

interface Body {
  denuncia_id: number;
  evidencias: {
    filename: string;
    base64Data: string;
    contentType: string;
  }[];
}

export async function processHandler(
  event: APIGatewayProxyEvent,
  callback: Callback
) {
  let prisma: TPrisma | null = null;
  try {
    const { BDName, BDUser, BDPassword, BDHost, BUCKET_NAME, AWS_REGION } =
      process.env as Record<string, string>;
    const body: Body = JSON.parse(event.body || "{}");
    if (!body.denuncia_id || !body.evidencias?.length)
      throw new Error("Datos incompletos");

    prisma = createPrismaClient({ BDName, BDUser, BDPassword, BDHost });
    
    let evidenciasCreadas: PrismaTypes.evidencia[] = [];

    await prisma.$transaction(async (tx) => {
      const keys = await Promise.all(
        body.evidencias.map(async (file) => {
          const ext = file.filename.split(".").pop() || "";
          const contentType = lookup(ext) || "application/octet-stream";
          const key = `denuncias/${body.denuncia_id}/${Date.now()}-${
            file.filename
          }`;

          await uploadFile({
            bucket: BUCKET_NAME!,
            key,
            base64Data: file.base64Data,
            contentType,
            region: AWS_REGION!,
          });

          const evidenciaCreada = await tx.evidencia.create({
            data: {
              key_s3: key,
              denuncias_id: body.denuncia_id,
            },
          });

          return evidenciaCreada;
        })
      );

      evidenciasCreadas = keys;
    });

    LambdaResponseUtils.success({
      data: evidenciasCreadas,
      callback,
      message: "Evidencias subidas correctamente",
      statusCode: "OK",
    });

    LambdaResponseUtils.success({
      data: evidenciasCreadas,
      callback,
      message: "Evidencias subidas correctamente",
      statusCode: "OK",
    });
  } catch (err) {
    console.error(err);
    LambdaResponseUtils.error({
      errorData: err,
      callback,
      message: "Error subiendo evidencias",
      statusCode: "INTERNAL_SERVER_ERROR",
    });
  } finally {
    if (prisma) await prisma.$disconnect();
  }
}

export const handler: Handler = async (
  _event: any,
  context: Context,
  callback: Callback
) => {
  context.callbackWaitsForEmptyEventLoop = false;
  return await processHandler(_event, callback);
};
