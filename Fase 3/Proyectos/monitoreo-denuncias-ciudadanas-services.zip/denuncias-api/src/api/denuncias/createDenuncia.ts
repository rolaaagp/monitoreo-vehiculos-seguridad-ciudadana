import {
  LambdaResponseUtils,
  Callback,
  Context,
  Handler,
  APIGatewayProxyEvent,
  uploadFile,
  lookup,
} from "utils";
import { createPrismaClient } from "database";

type TPrisma = ReturnType<typeof createPrismaClient>;

interface Body {
  ubicacion: string;
  detalle: string;
  fecha_completa: string;
  user_id: number;
  tipo_denuncia?: number;
  requerimiento_id?: number;
  latitud: number;
  longitud: number;
  evidencias?: {
    filename: string;
    base64Data: string;
    contentType: string;
  }[];
}

export async function processHandler(
  event: APIGatewayProxyEvent,
  callback: Callback
) {
  let prisma: TPrisma | null = null;
  try {
    const { BDName, BDUser, BDPassword, BDHost } = process.env as Record<
      string,
      string
    >;

    const body: Body = JSON.parse(event?.body as string);

    prisma = createPrismaClient({ BDName, BDUser, BDPassword, BDHost });

    await prisma.$transaction(async (tx) => {
      const denuncia = await tx.denuncias.create({
        data: {
          detalle: body.detalle,
          fecha: body.fecha_completa,
          users_id: body.user_id,
          latitud: body.latitud,
          longitud: body.longitud,
          ubicacion: body.ubicacion,
          folio: Math.floor(1000 + Math.random() * 9000),
          tipos_denuncias_id: body.tipo_denuncia,
          requerimiento_id: body.requerimiento_id,
          es_anonimo: true
        },
      });

      if (body?.evidencias && body?.evidencias?.length > 0) {
        const keys = await Promise.all(
          (body.evidencias || []).map(async (x) => {
            const ext = x.filename.split(".").pop() || "";
            const contentType = lookup(ext) || "application/octet-stream";
            const key = `denuncias/${denuncia.folio}/${Date.now()}-${
              x.filename
            }`;

            await uploadFile({
              bucket: process.env.BUCKET_NAME!,
              key,
              base64Data: x.base64Data,
              contentType,
              region: process.env.AWS_REGION!,
            });

            return { key, contentType };
          })
        );

        if (keys.length > 0) {
          await tx.evidencia.createMany({
            data: keys.map((k) => ({
              key_s3: k.key,
              denuncias_id: denuncia.id,
            })),
          });
        }

        await tx.evidencia.findMany({
          where: { denuncias_id: denuncia.id },
        });
      }
    });
    LambdaResponseUtils.success({
      data: { do: true },
      callback,
      message: "Realizado correctamente",
      statusCode: "OK",
    });
  } catch (err) {
    console.error("Error general -> ", err);
    LambdaResponseUtils.error({
      errorData: err,
      callback,
      message: "Ha ocurrido un error",
      statusCode: "INTERNAL_SERVER_ERROR",
    });
  } finally {
    if (prisma) await prisma.$disconnect();
  }
}

export const handler: Handler = async (
  _event: any,
  context: Context,
  callback: Callback
) => {
  context.callbackWaitsForEmptyEventLoop = false;
  return await processHandler(_event, callback);
};
