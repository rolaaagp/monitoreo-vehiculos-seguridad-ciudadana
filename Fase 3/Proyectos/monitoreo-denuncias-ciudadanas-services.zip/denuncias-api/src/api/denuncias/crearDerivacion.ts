import { LambdaResponseUtils, Callback, Context, Handler } from "utils";
import { createPrismaClient } from "database";

type TPrisma = ReturnType<typeof createPrismaClient>;

interface Body {
  detalle?: string;
  denuncia_id: number;
  estados_derivacion_id: number;
  tipo_derivacion_id: number;
  user_id: number;
}

export async function processHandler(event: any, callback: Callback) {
  let prisma: TPrisma | null = null;

  try {
    const { BDName, BDUser, BDPassword, BDHost } = process.env as Record<
      string,
      string
    >;

    const body: Body = JSON.parse(event?.body as string);

    prisma = createPrismaClient({ BDName, BDUser, BDPassword, BDHost });

    const resultado = await prisma.$transaction(async (tx) => {
      const created = await tx.derivaciones.create({
        data: {
          detalle: body.detalle,
          denuncias_id: body.denuncia_id,
          estados_derivacion_id: body.estados_derivacion_id,
          tipo_derivacion_id: body.tipo_derivacion_id,
        },
        include: {
          tipo_derivacion: true,
          estado_derivacion: true,
        },
      });

      const user = await tx.users.findUnique({
        where: { id: body.user_id },
      });
      const historial = await tx.historial_gestiones.create({
        data: {
          denuncias_id: body.denuncia_id,
          users_id: body.user_id,
          accion: "Derivación",
          detalle: `Derivación realizada a: ${created.tipo_derivacion?.nombre.toUpperCase()} por ${
            user?.fullname
          }`,
        },
      });
      return { historial, created };
    });

    LambdaResponseUtils.success({
      data: {
        historial: resultado.historial,
        derivacion: resultado.created,
      },
      callback,
      message: "Realizado correctamente",
      statusCode: "OK",
    });
  } catch (err) {
    console.error("Error general -> ", err);
    LambdaResponseUtils.error({
      errorData: err,
      callback,
      message: "Ha ocurrido un error",
      statusCode: "INTERNAL_SERVER_ERROR",
    });
  } finally {
    if (prisma) await prisma.$disconnect();
  }
}

export const handler: Handler = async (
  _event: any,
  context: Context,
  callback: Callback
) => {
  context.callbackWaitsForEmptyEventLoop = false;
  return await processHandler(_event, callback);
};
