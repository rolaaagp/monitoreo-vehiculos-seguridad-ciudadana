import { LambdaResponseUtils, Callback, Context, Handler } from "utils";
import { createPrismaClient } from "database";

type TPrisma = ReturnType<typeof createPrismaClient>;

interface Body {
  denuncia_id: number;
  nombre_requerimiento: string;
  tipo_prioridad_id: number;
  user_id: number;
}

export async function processHandler(event: any, callback: Callback) {
  let prisma: TPrisma | null = null;

  try {
    const { BDName, BDUser, BDPassword, BDHost } = process.env as Record<
      string,
      string
    >;

    const body: Body = JSON.parse(event?.body as string);

    prisma = createPrismaClient({ BDName, BDUser, BDPassword, BDHost });

    const resultado = await prisma.$transaction(async (tx) => {
      const created = await tx.requerimiento_adicional_denuncia.create({
        data: {
          nombre: body.nombre_requerimiento,
          tipo_prioridad_id: body.tipo_prioridad_id,
          denuncia_id: body.denuncia_id,
        },
        include: {
          tipo_prioridad: true,
        }
      });

      const user = await tx.users.findUnique({
        where: { id: body.user_id },
      });
      const historial = await tx.historial_gestiones.create({
        data: {
          denuncias_id: body.denuncia_id,
          users_id: body.user_id,
          accion: "Requerimiento",
          detalle: `Requerimiento nuevo registrado: ${body.nombre_requerimiento.toUpperCase()} por ${
            user?.fullname
          }`,
        },
      });
      return { historial, created };
    });

    LambdaResponseUtils.success({
      data: { historial: resultado.historial, requerimiento: resultado.created },
      callback,
      message: "Realizado correctamente",
      statusCode: "OK",
    });
  } catch (err) {
    console.error("Error general -> ", err);
    LambdaResponseUtils.error({
      errorData: err,
      callback,
      message: "Ha ocurrido un error",
      statusCode: "INTERNAL_SERVER_ERROR",
    });
  } finally {
    if (prisma) await prisma.$disconnect();
  }
}

export const handler: Handler = async (
  _event: any,
  context: Context,
  callback: Callback
) => {
  context.callbackWaitsForEmptyEventLoop = false;
  return await processHandler(_event, callback);
};
