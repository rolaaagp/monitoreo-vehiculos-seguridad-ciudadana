import { LambdaResponseUtils, Callback, Context, Handler } from "utils";
import { createPrismaClient } from "database";

type TPrisma = ReturnType<typeof createPrismaClient>;

export async function processHandler(event: any, callback: Callback) {
  let prisma: TPrisma | null = null;

  try {
    const { BDName, BDUser, BDPassword, BDHost } = process.env as Record<
      string,
      string
    >;
    prisma = createPrismaClient({ BDName, BDUser, BDPassword, BDHost });

    const startOfToday = new Date();
    startOfToday.setHours(0, 0, 0, 0);

    const endOfToday = new Date();
    endOfToday.setHours(23, 59, 59, 999);

    const creadasHoy = await prisma.denuncias.count({
      where: {
        fecha_creacion: {
          gte: startOfToday,
          lte: endOfToday,
        },
      },
    });

    // Obtener total por estado y top 3 requerimientos
    const estados = await prisma.estados_denuncia.findMany({
      where: { activo: true },
    });
    const result: {
      estado_id: number;
      estado_nombre: string;
      total_denuncias: number;
      top3_requerimientos: { nombre: string; cantidad: number }[];
    }[] = [];

    for (const estado of estados) {
      const denuncias = await prisma.denuncias.findMany({
        where: { estado_id: estado.id },
        include: {
          requerimiento: true,
          requerimiento_adicional_denuncia: true,
        },
      });

      // Total de denuncias
      const total = denuncias.length;

      // Contar requerimientos
      const countMap: Record<string, number> = {};
      denuncias.forEach((d) => {
        if (d.requerimiento)
          countMap[d.requerimiento.nombre] =
            (countMap[d.requerimiento.nombre] || 0) + 1;
        d.requerimiento_adicional_denuncia.forEach(
          (r) => (countMap[r.nombre] = (countMap[r.nombre] || 0) + 1)
        );
      });

      // Top 3 requerimientos
      const top3 = Object.entries(countMap)
        .map(([nombre, cantidad]) => ({ nombre, cantidad }))
        .sort((a, b) => b.cantidad - a.cantidad)
        .slice(0, 3);

      result.push({
        estado_id: estado.id,
        estado_nombre: estado.nombre,
        total_denuncias: total,
        top3_requerimientos: top3,
      });
    }

    LambdaResponseUtils.success({
      data: { top3PorEstado: result, creadasHoy },
      callback,
      message: "Datos de denuncias por estado obtenidos correctamente",
      statusCode: "OK",
    });
  } catch (err) {
    console.error("Error general -> ", err);
    LambdaResponseUtils.error({
      errorData: err,
      callback,
      message: "Ha ocurrido un error",
      statusCode: "INTERNAL_SERVER_ERROR",
    });
  } finally {
    if (prisma) await prisma.$disconnect();
  }
}

export const handler: Handler = async (
  _event: any,
  context: Context,
  callback: Callback
) => {
  context.callbackWaitsForEmptyEventLoop = false;
  return await processHandler(_event, callback);
};
